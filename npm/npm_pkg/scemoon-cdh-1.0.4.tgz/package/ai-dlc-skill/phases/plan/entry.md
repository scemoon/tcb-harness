---
name: ai-dlc-plan
description: "Plan Phase: Design Doc → Task DAG → Test Plan"
triggers:
  - plan
  - design
  - task-list
---

# Plan Phase (规划)

Convert approved spec into technical design and task decomposition.

## Entry

See `lifecycle.md` for the full phase flow.
See `rules.md` for enforceable rules (PLN-001 to PLN-004).
See `prompt.md` for the sub-agent delegation prompt template.

## 当被委派时

1. 读取 spec-delta 和 feature 文件
2. 生成设计文档（per-component + integration）
3. 分解为带 DAG 依赖的任务单元
4. 编写测试计划（每层）
