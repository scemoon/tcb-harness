from __future__ import annotations

import asyncio
import json
import logging
import re
from pathlib import Path
from typing import Any, AsyncIterator, Optional

from dataclasses import dataclass
from typing import Callable

from onecode.agent.agents.types import AgentPermission
from onecode.agent.context import ContextManager
from onecode.agent.permissions_store import PermissionStore
from onecode.models.provider import ContentBlockType, ProviderRegistry

from onecode.agent.session import AgentSession
from onecode.memory import AgentMemory, MemoryLayer
from onecode.models.errors import safe_error_msg
from onecode.models.messages import StreamEvent, StreamEventType

logger = logging.getLogger("onecode.agent.engine")

# Subagent depth limit — subagents are leaf nodes (max depth = 1).
_MAX_SUBAGENT_DEPTH = 1


@dataclass(frozen=True)
class ToolEvent:
    """Event emitted during the agent loop lifecycle (Clawd-Code style)."""
    kind: str  # "tool_use" | "tool_result" | "tool_error"
    tool_name: str = ""
    tool_input: dict | None = None
    tool_output: Any = None
    tool_use_id: str | None = None
    is_error: bool = False
    error: str | None = None


ToolEventHandler = Callable[[ToolEvent], None]


class TurnCancelledError(Exception):
    """Raised when the user cancels the agent's turn mid-execution."""


TOOL_CALL_RE = re.compile(
    r'<tool_call\s+name=["\']([^"\']+)["\']\s+id=["\']([^"\']+)["\']>(.*?)</tool_call>',
    re.DOTALL,
)

# Structured tool call format used by the minimaxi / claude / Anthropic-style
# models.  Looks like::
#
#     <minimax:tool_call>
#     <invoke name="Read">
#     <parameter name="path">SPEC.md</parameter>
#     </invoke>
#     <invoke name="Bash">
#     <parameter name="command">ls -la</parameter>
#     <parameter name="timeout">30</parameter>
#     </invoke>
#     </minimax:tool_call>
#
# We match the outer block, then split into individual <invoke> elements
# inside ``_extract_minimax_tool_uses``.
MINIMAX_TOOL_CALL_RE = re.compile(
    r'<minimax:tool_call>(.*?)</minimax:tool_call>',
    re.DOTALL,
)

# An individual <invoke name="X">...</invoke> block.  ``name`` is captured
# separately so we can call ``_parse_minimax_invoke_body`` on the inner XML.
_MINIMAX_INVOKE_RE = re.compile(
    r'<invoke\s+name="([^"]+)">(.*?)</invoke>',
    re.DOTALL,
)

# A single <parameter name="X">value</parameter> element.  The value can span
# multiple lines, may contain entity-escaped angle brackets, and we tolerate
# either double or single quotes around the name.
_MINIMAX_PARAM_RE = re.compile(
    r'<parameter\s+name=["\']([^"\']+)["\']>(.*?)</parameter>',
    re.DOTALL,
)

THINKING_RE = re.compile(
    r'<think(?:ing)?>(.*?)</think(?:ing)?>',
    re.DOTALL,
)

_LEGACY_OPEN = "[TOOL_CALL]"
_LEGACY_CLOSE = "[/TOOL_CALL]"


def _parse_minimax_invoke_body(body: str) -> dict:
    """Parse the inner XML of a single ``<invoke name="X">`` block.

    Returns a dict ``{"name": str, "arguments": {param_name: value, ...}}``.
    The ``arguments`` dict is empty if no ``<parameter>`` children are found.
    """
    body = body.strip()
    arguments: dict = {}
    for m in _MINIMAX_PARAM_RE.finditer(body):
        param_name = m.group(1)
        raw_value = m.group(2)
        arguments[param_name] = _unescape_xml(raw_value)
    return arguments


def _unescape_xml(s: str) -> str:
    """Reverse the common XML / HTML entity escapes.

    We keep this conservative — the five predefined entities and the numeric
    ones — so we never accidentally mangle content that legitimately contains
    ampersands.
    """
    return (
        s.replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", '"')
        .replace("&apos;", "'")
        .replace("&amp;", "&")
    )


def _extract_minimax_tool_uses(text: str, id_start: int = 0) -> tuple[list[dict], str, int]:
    """Extract ``<minimax:tool_call>...</minimax:tool_call>`` blocks.

    Returns ``(tool_uses, cleaned_text, next_id)`` where ``tool_uses`` is a
    list of ``{id, name, input}`` dicts and ``cleaned_text`` has every
    matched block removed.  ``id_start`` is the next available tool id
    counter (caller-owned, see ``AgentEngine._tool_id_counter``); the next
    free id is returned in the tuple so callers can pass it to subsequent
    extractions without losing uniqueness.
    """
    tool_uses: list[dict] = []
    cleaned = text
    counter = id_start
    while True:
        m = MINIMAX_TOOL_CALL_RE.search(cleaned)
        if m is None:
            break
        block_body = m.group(1)
        for inv in _MINIMAX_INVOKE_RE.finditer(block_body):
            name = inv.group(1)
            arguments = _parse_minimax_invoke_body(inv.group(2))
            counter += 1
            tool_uses.append({
                "id": f"minimax-{counter}",
                "name": name,
                "input": arguments,
            })
        cleaned = cleaned[:m.start()] + cleaned[m.end():]
    return tool_uses, cleaned, counter


def _scan_balanced_braces(text: str, open_pos: int) -> int | None:
    if open_pos < 0 or open_pos >= len(text) or text[open_pos] != "{":
        return None
    depth = 0
    i = open_pos
    n = len(text)
    while i < n:
        c = text[i]
        if c == "{":
            depth += 1
            i += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return i
            i += 1
        elif c in ('"', "'"):
            quote = c
            i += 1
            while i < n and text[i] != quote:
                if text[i] == "\\" and i + 1 < n:
                    i += 2
                else:
                    i += 1
            i += 1
        elif c == "/" and i + 1 < n and text[i + 1] == "/":
            while i < n and text[i] != "\n":
                i += 1
        else:
            i += 1
    return None


def _parse_legacy_tool_body(body: str) -> dict:
    body = body.strip()
    if not body or not body.startswith("{"):
        return {"name": None, "arguments": {}}
    body_close = _scan_balanced_braces(body, 0)
    if body_close is None:
        return {"name": None, "arguments": {}}
    inner = body[1:body_close]
    name_match = re.search(r'tool\s*=>\s*"([^"]+)"', inner)
    name = name_match.group(1) if name_match else None
    arguments: dict = {}
    args_match = re.search(r'args\s*=>\s*\{', inner)
    if args_match:
        args_outer = _scan_balanced_braces(inner, args_match.end() - 1)
        if args_outer is not None:
            args_body = inner[args_match.end():args_outer]
            for am in re.finditer(
                r'--(\w+)\s+"((?:[^"\\]|\\.)*)"', args_body, re.DOTALL
            ):
                arguments[am.group(1)] = am.group(2)
    return {"name": name, "arguments": arguments}


def _extract_legacy_tool_uses(
    text: str, id_start: int = 0
) -> tuple[list[dict], str, int]:
    """Extract all [TOOL_CALL]...[/TOOL_CALL] blocks from text.

    Returns (tool_uses, cleaned_text, next_id) where tool_uses has
    [{id, name, input}, ...] and cleaned_text has all markers removed.
    ``id_start`` lets the caller share a monotonic counter across multiple
    extraction passes; the next free id is returned so callers can pass it
    forward.
    """
    tool_uses: list[dict] = []
    cleaned = text
    counter = id_start
    while True:
        open_idx = cleaned.find(_LEGACY_OPEN)
        if open_idx < 0:
            break
        body_start = open_idx + len(_LEGACY_OPEN)
        close_idx = cleaned.find(_LEGACY_CLOSE, body_start)
        if close_idx < 0:
            # Unclosed marker — stop looking
            break
        body = cleaned[body_start:close_idx]
        span_end = close_idx + len(_LEGACY_CLOSE)
        parsed = _parse_legacy_tool_body(body)
        name = parsed.get("name")
        if name:
            counter += 1
            tool_uses.append({
                "id": f"legacy-{counter}",
                "name": name,
                "input": parsed.get("arguments", {}),
            })
        cleaned = cleaned[:open_idx] + cleaned[span_end:]
    return tool_uses, cleaned, counter


_TODO_STATUSES = {"pending", "in_progress", "completed"}


class TodoManager:
    """Unified todo manager (formerly TodoManager).

    Each todo has: id, subject, description, activeForm, status, owner, blocks,
    blockedBy, metadata, output. Supports dependency tracking and progress
    display in the TUI Plan sidebar.

    Persistence format (``to_dict``/``from_dict``) accepts both the new
    single-list layout and the legacy ``{"tasks": [...], "todos": [...]}``
    layout for backwards compatibility with existing session files.
    """

    def __init__(self, on_change: Callable[[], None] | None = None):
        self._todos: dict[str, dict] = {}
        self._order: list[str] = []
        self._id_counter = 0
        self._on_change = on_change

    def _mark_dirty(self) -> None:
        if self._on_change:
            self._on_change()

    def _next_id(self) -> str:
        self._id_counter += 1
        return f"t{self._id_counter}"

    # ── Todo CRUD ──

    def create_todo(
        self,
        subject: str,
        description: str = "",
        active_form: str = "",
        metadata: dict | None = None,
    ) -> dict:
        """Create a todo with dependency tracking support."""
        todo_id = self._next_id()
        todo = {
            "id": todo_id,
            "_order": self._id_counter,
            "subject": subject,
            "description": description,
            "activeForm": active_form,
            "status": "pending",
            "owner": None,
            "blocks": [],
            "blockedBy": [],
            "metadata": dict(metadata or {}),
            "output": "",
        }
        self._todos[todo_id] = todo
        self._order.append(todo_id)
        self._mark_dirty()
        return todo

    def get_todo(self, todo_id: str) -> dict | None:
        return self._todos.get(todo_id)

    def list_todos(self) -> list[dict]:
        """List all todos in creation order."""
        return [self._todos[tid] for tid in self._order if tid in self._todos]

    def update_todo(self, todo_id: str, **fields) -> dict | None:
        """Update todo fields. Supports: subject, description, activeForm, status,
        owner, metadata, addBlocks, addBlockedBy. Returns updated todo or None."""
        todo = self._todos.get(todo_id)
        if todo is None:
            return None

        updated = []

        for field in ("subject", "description", "activeForm", "owner"):
            if field in fields:
                v = fields[field]
                if isinstance(v, str) and v != todo.get(field):
                    todo[field] = v
                    updated.append(field)

        if "status" in fields:
            status = fields["status"]
            if status == "deleted":
                self._todos.pop(todo_id, None)
                if todo_id in self._order:
                    self._order.remove(todo_id)
                self._mark_dirty()
                return {"id": todo_id, "deleted": True}
            if status in _TODO_STATUSES and status != todo.get("status"):
                todo["status"] = status
                updated.append("status")

        for rel_field, input_key in (("blocks", "addBlocks"), ("blockedBy", "addBlockedBy")):
            if input_key in fields:
                ids = fields[input_key]
                if isinstance(ids, list):
                    cur = list(todo.get(rel_field) or [])
                    for x in ids:
                        if isinstance(x, str) and x not in cur:
                            cur.append(x)
                    if cur != todo.get(rel_field):
                        todo[rel_field] = cur
                        updated.append(rel_field)

        if "metadata" in fields:
            md = fields["metadata"]
            if isinstance(md, dict):
                existing = dict(todo.get("metadata") or {})
                for k, v in md.items():
                    if v is None:
                        existing.pop(k, None)
                    else:
                        existing[k] = v
                todo["metadata"] = existing
                updated.append("metadata")

        if "output" in fields:
            v = fields["output"]
            if isinstance(v, str):
                todo["output"] = v
                updated.append("output")

        self._mark_dirty()
        return todo

    def get_todo_output(self, todo_id: str) -> dict:
        """Get output for a todo."""
        todo = self._todos.get(todo_id)
        if todo is None:
            return {"retrieval_status": "not_found", "task": None}
        output = str(todo.get("output") or "")
        return {
            "retrieval_status": "success" if output else "not_ready",
            "task": {
                "task_id": todo_id,
                "task_type": "todo_list",
                "status": todo.get("status"),
                "description": todo.get("description"),
                "output": output,
            },
        }

    def clear_todos(self) -> None:
        self._todos.clear()
        self._order.clear()
        self._id_counter = 0
        self._mark_dirty()

    # ── Serialization ──

    def to_dict(self) -> dict:
        """Serialize todos for persistence."""
        return {
            "todos": [dict(self._todos[tid]) for tid in self._order if tid in self._todos],
            "id_counter": self._id_counter,
        }

    @classmethod
    def from_dict(cls, data: dict, on_change: Callable[[], None] | None = None) -> "TodoManager":
        """Restore todo manager from saved dict.

        Accepts the unified ``{"todos": [...]}`` layout (preferred) and the
        legacy ``{"tasks": [...], "todos": [...]}`` layout where ``todos``
        entries may use the old ``{text, done}`` shape — these are converted
        on the fly to the new ``{subject, status}`` shape.
        """
        tm = cls(on_change=on_change)
        tm.reload_from_dict(data)
        return tm

    def reload_from_dict(self, data: dict) -> None:
        """Reload state from *data* in place, preserving the instance identity.

        This is critical because tool instances (``TodoCreateTool`` etc.)
        hold a direct reference to the same ``TodoManager`` object.  If we
        replaced ``self._todo_manager`` with a new instance, the tools
        would silently write to the stale one while the engine reads from
        the fresh one — creating the illusion of success but never
        persisting or emitting plan updates.
        """
        self._todos.clear()
        self._order.clear()
        self._id_counter = data.get("id_counter", 0)

        raw_todos: list[dict] = []
        if "todos" in data:
            raw_todos.extend(data.get("todos") or [])
        if "tasks" in data:
            raw_todos.extend(data.get("tasks") or [])

        for t in raw_todos:
            todo = dict(t)
            if "subject" not in todo and "text" in todo:
                todo["subject"] = todo.pop("text")
            if "status" not in todo and "done" in todo:
                todo["status"] = "completed" if todo.pop("done") else "pending"
            todo.setdefault("status", "pending")
            tid = todo.get("id") or self._next_id()
            todo["id"] = tid
            todo.setdefault("_order", self._id_counter)
            self._todos[tid] = todo
            if tid not in self._order:
                self._order.append(tid)


# Tools that require a task plan before execution (plan gate)
_EXECUTION_TOOLS: frozenset[str] = frozenset({
    "Write", "Edit", "Insert", "ApplyPatch", "Bash",
})


class AgentEngine:
    def __init__(self, app, project_dir: Path | None = None, perm_store: PermissionStore | None = None):
        from onecode.agent.tools.file_ops import ToolFactory
        from onecode.agent.agents.types import BuildAgent
        from onecode.agent.hooks import HookManager
        from onecode.skills.loader import SkillLoader
        from onecode.mcp.manager import MCPManager
        from onecode.agent.tools.cron_tools import CronScheduler
        from onecode.agent.tools.lsp_tools import LSPTool
        from onecode.agent.tools.config_tool import ConfigReadTool, ConfigWriteTool
        from onecode.agent.tools.communication_tools import SendMessageTool
        self.app = app
        self._project_dir = (project_dir or Path.cwd()).resolve()
        self.context = ContextManager()
        self.file_ops = ToolFactory.create_file_ops(self._project_dir)
        self.shell = ToolFactory.create_shell(self._project_dir)
        self.current_agent: AgentConfig = BuildAgent()  # noqa: F821
        self.iterations = 0
        self.total_tokens = 0
        self._skills_loaded = False
        self._session: Optional[AgentSession] = None
        self._memory = AgentMemory()
        self._hooks = HookManager()
        self._todo_manager = TodoManager(on_change=self._on_todo_change)
        self._plan_dirty: bool = False
        # Cache of the last plan snapshot that was emitted to the TUI.  Used
        # by ``_emit_plan_update`` to dedupe redundant emits when the todos
        # have not actually changed between turns.  The first emit of a
        # session/cycle always wins (cache starts empty).
        self._last_emitted_plan: tuple = ()
        self._project_config: dict = {}
        self._project_context_loaded = False
        self._pending_approval: dict | None = None  # {tool_call, result_key}
        self._last_user_msg: str | None = None  # Last SendMessage visible to user

        # Clawd-Code subsystems
        self._skill_loader = SkillLoader()
        self._mcp = MCPManager()
        self._cron_scheduler = CronScheduler()
        self._lsp_tool = LSPTool()
        app_config = getattr(app, 'config', None)
        self._config_tool_read = ConfigReadTool(app_config) if app_config else None
        self._config_tool_write = ConfigWriteTool(app_config) if app_config else None

        # Codebase engine (lazy init)
        self._codebase_engine: Optional["CodebaseEngine"] = None  # noqa: F821

        # Tool registry (Clawd-Code pattern)
        self._tool_registry = self._build_tool_registry()
        self._send_message_tool = SendMessageTool()

        # Per-turn usage tracking (Clawd-Code style)
        self._turn_usages: list[dict[str, int]] = []

        # Event callbacks
        self.on_event: ToolEventHandler | None = None
        self.on_text_chunk: Callable[[str], None] | None = None
        self.on_tool_call_delta: Callable[[str, str, str], None] | None = None
        self.on_thinking: Callable[[str], None] | None = None
        self._streaming_used: bool = False
        self._pending_thinking_blocks: list[str] = []

        # Cancellation support
        self._cancelled: bool = False

        # Subagent depth limit — subagents are leaf nodes (max depth = 1).
        self._subagent_depth: int = 0

        # Skip codebase auto-retrieval / long-term memory recall inside
        # subagent engines.  Both are project-seeding steps meant for the
        # top-level chat loop; a subagent already receives a fully-formed
        # explicit prompt from the parent and does NOT need toEmbed/index
        # the whole codebase or recall memories again — that path
        # previously called ``CodebaseIndexer.index()`` (a long
        # synchronous loop, blocking the event loop and cancel) plus
        # ``CodebaseRetriever._retrieve_embedding()`` (one httpx call per
        # chunk, each with a 30s timeout, so ~minutes of dead time), which
        # is the root cause of the "subagent shows no stream output and
        # can't be stopped" hang observed in production.
        self._disable_retrieval: bool = False

        # Monotonic tool-call id counter — shared across every
        # ``chat_stream`` turn so the same id is never reused even when the
        # model re-emits ``legacy-0`` / ``minimax-0`` in a fresh turn.
        # Touched only by ``_extract_*_tool_uses`` through the engine
        # instance, not by the module-level helpers (which take an explicit
        # ``id_start`` for testability).
        self._tool_id_counter: int = 0

        # Subagent engines spawned by this engine — we track them so
        # cancelling the parent also cancels in-flight subagents.
        self._child_engines: list[AgentEngine] = []

        # Permission overrides shared across subagents
        self._perm_store: PermissionStore = perm_store or PermissionStore()

        # Plan gate: mode-aware enforcement based on agent type
        # "hard" (plan mode) rejects execution tools without plan
        # "soft" (build/solo mode) suggests planning but doesn't block
        # "off" (agents with permission_task=DENY) no enforcement
        self._plan_gate_mode: str = "off"
        self._plan_gate_fired: bool = False

        # ReAct state tracking
        self._react_phase: str = "thought"  # "thought" | "action" | "observation"
        self._direct_execution_count: int = 0  # Track direct tool use for routing-decision reminder

        # Consecutive turns with zero tool_uses — if the LLM repeatedly
        # refuses to call tools despite pending todos, we cap the loop
        # instead of cycling until max_turns is exhausted.
        self._empty_tool_turns: int = 0

    def _build_tool_registry(self) -> ToolRegistry:  # noqa: F821
        from onecode.agent.tools.registry import ToolRegistry
        from onecode.agent.tools.file_tools import ReadTool, WriteTool, EditTool, InsertTool, UndoEditTool, GlobTool, GrepTool, ListTool
        from onecode.agent.tools.apply_patch_tool import ApplyPatchTool
        from onecode.agent.tools.bash_tool import BashTool
        from onecode.agent.tools.web_tools import WebFetchTool, WebSearchTool
        from onecode.agent.tools.communication_tools import SendMessageTool, AskUserTool, ToolSearchTool
        from onecode.agent.tools.todo_tools import (TodoCreateTool, TodoGetTool, TodoListTool, TodoUpdateTool,
            TodoOutputTool, TodoStopTool, TodoClearTool)
        from onecode.agent.tools.agent_tools import AgentTool, TaskTool
        from onecode.agent.tools.skill_tools import SkillTool
        from onecode.agent.tools.mcp_tools import MCPTool as MCPToolTool, MCPResourcesTool
        from onecode.agent.tools.cron_tools import CronCreateTool, CronListTool, CronRemoveTool
        from onecode.agent.tools.git_tools import WorktreeTool
        registry = ToolRegistry()
        # File tools
        registry.register(ReadTool(self.file_ops))
        registry.register(WriteTool(self.file_ops))
        registry.register(EditTool(self.file_ops))
        registry.register(InsertTool(self.file_ops))
        registry.register(UndoEditTool(self.file_ops))
        registry.register(GlobTool(self.file_ops))
        registry.register(GrepTool(self.file_ops))
        registry.register(ListTool(self.file_ops))
        registry.register(ApplyPatchTool(self.file_ops))
        # Shell
        registry.register(BashTool(self.shell))
        # Web
        registry.register(WebFetchTool())
        registry.register(WebSearchTool())
        # Communication
        self._send_message_tool = SendMessageTool()
        registry.register(self._send_message_tool)
        registry.register(AskUserTool())
        registry.register(ToolSearchTool(registry))
        # Task management
        registry.register(TodoCreateTool(self._todo_manager))
        registry.register(TodoGetTool(self._todo_manager))
        registry.register(TodoListTool(self._todo_manager))
        registry.register(TodoUpdateTool(self._todo_manager))
        registry.register(TodoOutputTool(self._todo_manager))
        registry.register(TodoStopTool(self._todo_manager))
        registry.register(TodoClearTool(self._todo_manager))
        # Agent tools
        registry.register(AgentTool(registry, permission_checker=self._check_tool_permission))
        registry.register(TaskTool(self._spawn_subagent_async))

        # Skill tool (Clawd-Code pattern)
        registry.register(SkillTool(self._skill_loader))

        # MCP tools (Clawd-Code pattern)
        registry.register(MCPToolTool(self._mcp))
        registry.register(MCPResourcesTool(self._mcp))

        # LSP tool (Clawd-Code pattern)
        registry.register(self._lsp_tool)

        # Cron tools (Clawd-Code pattern)
        registry.register(CronCreateTool(self._cron_scheduler))
        registry.register(CronListTool(self._cron_scheduler))
        registry.register(CronRemoveTool(self._cron_scheduler))

        # Git worktree tool (Clawd-Code pattern)
        registry.register(WorktreeTool(workspace_root=self._project_dir))

        # Config tools (Clawd-Code pattern)
        if self._config_tool_read:
            registry.register(self._config_tool_read)
        if self._config_tool_write:
            registry.register(self._config_tool_write)

        # Codebase search tool (lazy — engine initialised on first search)
        from onecode.codebase.tools import CodebaseSearchTool
        registry.register(CodebaseSearchTool(lambda: self._codebase_engine))
        return registry

    def _resolve_plan_gate_mode(self) -> str:
        """Determine plan gate strictness based on current agent type.
        
        Returns "hard" (reject execution tools without plan), "soft" (nudge only),
        or "off" (no enforcement).
        """
        from onecode.agent.agents.types import AgentPermission
        if self.current_agent.permission_task == AgentPermission.DENY:
            return "off"
        if self.current_agent.name == "plan":
            return "hard"
        return "soft"

    def _plan_gate_first_turn(self) -> bool:
        """Returns True only on the first turn where no plan exists yet.
        
        Once tasks are created or the gate has fired, subsequent turns
        proceed without gate intervention.
        """
        if self._plan_gate_fired:
            return False
        self._plan_gate_fired = True
        return True

    def _notify_event(self, event: ToolEvent) -> None:
        """Emit a ToolEvent to the registered callback (Clawd-Code pattern)."""
        if self.on_event:
            try:
                self.on_event(event)
            except Exception as e:
                logger.warning("ToolEvent callback failed: %s", e)

    def _emit_text_chunks(self, text: str, chunk_size: int = 12) -> None:
        """Emit user-visible text in small chunks (Clawd-Code pattern)."""
        if self.on_text_chunk is None or not text:
            return
        if chunk_size <= 0:
            chunk_size = len(text)
        for idx in range(0, len(text), chunk_size):
            try:
                self.on_text_chunk(text[idx:idx + chunk_size])
            except Exception as e:
                logger.warning("on_text_chunk failed: %s", e)
                return

    def _emit_plan_update(self) -> list[StreamEvent]:
        """Emit a plan update event from current todos, deduped against last emit.

        Returns an empty list when the plan snapshot is byte-identical to the
        last emission, so callers can no-op without paying the JSON-RPC + TUI
        widget-recompose cost.  The cache is a tuple of ``(content, status,
        priority)`` triples — order-sensitive, so reordering the todo list
        also triggers a re-emit.
        """
        entries = [
            (
                t.get("subject") or t.get("description", ""),
                t.get("status", "pending"),
                t.get("metadata", {}).get("priority", "medium"),
            )
            for t in self._todo_manager.list_todos()
        ]
        if entries == self._last_emitted_plan:
            return []
        self._last_emitted_plan = entries
        # Convert the cached tuples back to wire-format dicts for the stream
        # event.  The TUI side expects dicts; the dedupe cache stays tuples
        # to avoid the per-emit dict-construction cost on the hot path.
        wire_entries = [
            {"content": c, "status": s, "priority": p}
            for (c, s, p) in entries
        ]
        return [StreamEvent.plan(wire_entries)]

    def _has_pending_todos(self) -> bool:
        """Return True if there are any pending or in-progress todos."""
        return any(
            t.get("status") in ("pending", "in_progress")
            for t in self._todo_manager.list_todos()
        )

    def _build_completion_summary(self) -> str:
        """Build a deterministic completion summary from todo state.

        Called after the agent loop exits when the last round had no
        visible text — ensures the user always sees a completion report
        without an extra LLM round-trip.
        """
        todos = self._todo_manager.list_todos()
        completed = [t for t in todos if t.get("status") == "completed"]
        failed = [t for t in todos if t.get("status") == "failed"]
        pending = [t for t in todos if t.get("status") in ("pending", "in_progress")]

        lines = ["\n---", "## Session Complete", ""]

        if not todos:
            lines.append("No todos were tracked in this session.")
        else:
            if completed:
                lines.append(f"**Completed** ({len(completed)}):")
                for t in completed:
                    lines.append(f"- {t.get('subject') or t.get('description', '')}")
                lines.append("")
            if pending:
                lines.append(f"**Unfinished** ({len(pending)}):")
                for t in pending:
                    lines.append(f"- {t.get('subject') or t.get('description', '')}")
                lines.append("")
            if failed:
                lines.append(f"**Failed** ({len(failed)}):")
                for t in failed:
                    lines.append(f"- {t.get('subject') or t.get('description', '')}")
                lines.append("")

        lines.append(
            f"**Stats**: {self.iterations} round(s), "
            f"{self.total_tokens} tokens"
        )
        return "\n".join(lines)

    def _auto_advance_after_spawn(self, subagent_prompt: str) -> None:
        """After a Spawn subagent completes, auto-advance todo status.

        Finds the first ``in_progress`` todo (typically the one the subagent
        was working on) and marks it ``completed``.  If another ``pending``
        todo remains, injects a user message into the LLM context directing
        the agent to continue — no need to wait for the LLM to spontaneously
        call ``TodoUpdate`` then ``Spawn`` again.
        """
        todos = self._todo_manager.list_todos()
        in_progress = [t for t in todos if t.get("status") == "in_progress"]
        if in_progress:
            tid = in_progress[0]["id"]
            self._todo_manager.update_todo(tid, status="completed")

        pending = [t for t in self._todo_manager.list_todos() if t.get("status") == "pending"]
        if pending:
            lines = ["# Continue working — remaining todos", ""]
            for t in pending:
                sub = t.get("subject", "")
                desc = t.get("description", "")
                if desc and desc != sub:
                    lines.append(f"- `{t['id']}`: {sub} — {desc}")
                else:
                    lines.append(f"- `{t['id']}`: {sub}")
            lines.append("")
            lines.append("Continue with the next pending todo above. Do NOT stop.")
            body = "\n".join(lines)
            self.context.add_message("user", [{"type": "text", "text": body}])

    def _refresh_pending_todos_nudge(self) -> None:
        """Inject a reminder that nudges the agent to advance unfinished todos.

        Called at the start of each ReAct turn. If there are pending or
        in-progress todos, a strong ``<!-- PENDING_TODOS -->`` section is
        injected into the system context directing the agent to continue
        working rather than summarising or stopping early.

        When no todos are open, any stale nudge is removed so the context
        stays clean.
        """
        marker = "<!-- PENDING_TODOS -->"
        open_todos = [t for t in self._todo_manager.list_todos()
                      if t.get("status") in ("pending", "in_progress")]
        if not open_todos:
            self.context.remove_system_by_marker(marker)
            return

        in_progress = [t for t in open_todos if t.get("status") == "in_progress"]
        pending = [t for t in open_todos if t.get("status") == "pending"]

        def _label(t: dict) -> str:
            sid = t.get("id", "?")
            sub = t.get("subject") or t.get("description", "")
            owner = t.get("owner")
            owner_part = f" (owner={owner})" if owner else ""
            return f"- `{sid}`{owner_part}: {sub}"

        lines: list[str] = []
        total = len(in_progress) + len(pending)
        lines.append(f"## ⚠️ Open todos ({total}) — you MUST continue working on these")
        lines.append("Do NOT end your turn until ALL todos below are completed.")
        if in_progress:
            labels = "\n".join(_label(t) for t in in_progress)
            lines.append(f"\nIn progress:\n{labels}")
        if pending:
            labels = "\n".join(_label(t) for t in pending)
            lines.append(f"\nPending:\n{labels}")
        lines.append(
            "\nFor each completed todo, call TodoUpdate(status=\"completed\") "
            "immediately. Then proceed to the next pending todo. "
            "Do NOT summarise or stop — keep working."
        )
        body = f"{marker}\n" + "\n".join(lines)
        if not self.context.replace_system_section(marker, body):
            self.context.add_system(body)

    def _on_todo_change(self) -> None:
        """Callback invoked by TodoManager whenever todos mutate.

        Sets a dirty flag so the next opportunity in ``chat_stream`` will
        emit a fresh plan event.  Decoupling the callback from the emit
        keeps the public API synchronous and avoids re-entrancy.

        Subagents have an isolated TodoManager and (since Todo tools are
        denied via disallowed_tools for subagents) cannot mutate the parent's
        shared plan, so this callback only fires for the main agent's own
        TodoManager.

        Also persists todos to ``.cdh/todos.json`` immediately so they
        survive a crash or Ctrl+C before the next ACP turn boundary.
        """
        self._plan_dirty = True
        self.save_todos_to_project()

    @property
    def _workspace(self) -> Path:
        return self._project_dir

    def set_agent(self, agent_type: str) -> None:
        from onecode.agent.agents.types import (
            AgentMode,
            AgentPermission,
            SUBAGENT_CONSTRAINTS,
            create_agent,
            PLAN_GATE_HARD,
            PLAN_GATE_SOFT,
            REACT_WORKFLOW,
            filter_tool_descriptions,
        )
        self.current_agent = create_agent(agent_type)
        system_parts = [self.current_agent.description]

        edit_ask = self.current_agent.should_ask_for_edit()
        bash_ask = self.current_agent.should_ask_for_bash()
        if edit_ask or bash_ask:
            restrictions = []
            if edit_ask:
                restrictions.append("- File edits require user approval")
            if bash_ask:
                restrictions.append("- Shell commands require user approval")
            system_parts.append("\n".join(restrictions))

        if self.current_agent.mode == AgentMode.SUBAGENT:
            system_parts.append(SUBAGENT_CONSTRAINTS)

        if self.current_agent.permission_task != AgentPermission.DENY:
            system_parts.append(REACT_WORKFLOW)
            if self.current_agent.mode.name == "SUBAGENT":
                pass  # subagents don't need plan gate
            elif self.current_agent.permission_edit == AgentPermission.DENY and self.current_agent.permission_bash == AgentPermission.DENY:
                pass  # read-only mode, no gate needed
            elif self.current_agent.permission_task == AgentPermission.DENY:
                pass
            else:
                gate = PLAN_GATE_HARD if self.current_agent.mode == AgentMode.PRIMARY and self.current_agent.name == "plan" else PLAN_GATE_SOFT
                system_parts.append(gate)

        # Response style with CoT reasoning guidance.
        if self.current_agent.mode == AgentMode.SUBAGENT:
            # Subagents: simple CoT guidance without Todo/Spawn instructions.
            system_parts.append(
                "\n## Response style\n"
                "- **Every round must start with Chain of Thought reasoning** "
                "inside `<thinking>`. Review the last round's tool results, "
                "assess progress, and decide the next action.\n"
                "- If you need to reason between tool calls, wrap your "
                "reasoning in `<thinking>...</thinking>`.  The TUI will "
                "render the wrapped block as a collapsible thought and "
                "keep it out of the main answer.\n"
                "- **Intermediate rounds**: visible text is for progress "
                "updates, status reports, and questions.  Do NOT announce "
                '"done" or "complete" unless ALL work is actually finished.\n'
                "- **FINAL round** (all work done): output a visible summary "
                "describing what was accomplished, changed, or decided.\n"
            )
        else:
            system_parts.append(
                "\n## Response style\n"
                "- **Every round must start with Chain of Thought reasoning** "
                "inside `<thinking>`. Review the last round's tool results, "
                "assess progress against todos, and decide the next action. "
                "Then plan with `TodoCreate` and route execution by complexity.\n"
                "- **Plan + execution routing**:\n"
                "  - Every task is a `TodoCreate` (persisted to .cdh/todos.json, "
                "sidebar Plan). No work without a todo.\n"
                "  - Simple / single-step todo → execute directly, then "
                "`TodoUpdate(status=\"completed\")`.\n"
                "  - Complex / multi-step todo → `Spawn(agent_type, prompt)` to "
                "delegate execution to an isolated subagent, then "
                "`TodoUpdate(status=\"completed\")`.\n"
                "  - Use `TodoClear` to reset the entire plan and start fresh.\n"
                "- If you need to reason between tool calls, wrap your "
                "reasoning in `<thinking>...</thinking>`.  The TUI will "
                "render the wrapped block as a collapsible thought and "
                "keep it out of the main answer.\n"
                "- **Intermediate rounds**: visible text is for progress "
                "updates, status reports, and user questions.  Do NOT "
                'announce "done", "complete", or "task finished" unless '
                "ALL todos are actually completed.\n"
                "- Do NOT call `TodoUpdate(status=\"completed\")` unless you "
                "have actually executed the work (tool calls or Spawn).\n"
                "- **FINAL round** (all todos completed, all work done): "
                "output a visible summary describing what was accomplished, "
                "what was changed, and any important outcomes or limitations.\n"
            )

        tagged_content = "<!-- AGENT_CONFIG -->\n" + "\n".join(system_parts)
        if not self.context.replace_system_section("AGENT_CONFIG", tagged_content):
            self.context.add_system(tagged_content)

        # Inject TOOL_DESCRIPTIONS as its own marker so it can be independently
        # stripped when the provider supports native tool schemas.
        tool_desc = filter_tool_descriptions(
            allowlist=self.current_agent.tools or None,
            denylist=self.current_agent.disallowed_tools or None,
        )
        tool_tagged = "<!-- TOOL_DESCRIPTIONS -->\n" + tool_desc
        if not self.context.replace_system_section("TOOL_DESCRIPTIONS", tool_tagged):
            self.context.add_system(tool_tagged)

        # Re-apply user permission overrides (e.g. "allow always")
        self._perm_store.apply_to(self.current_agent)

    def _strip_agent_config_tool_descriptions(self) -> None:
        """Remove the ``<!-- TOOL_DESCRIPTIONS -->`` system section.

        Called after the provider is known, for providers that support
        native tool schemas and don't need the prose TOOL_DESCRIPTIONS.
        """
        self.context.remove_system_by_marker("<!-- TOOL_DESCRIPTIONS -->")

    def get_available_tools(self) -> str:
        from onecode.agent.agents.types import filter_tool_descriptions
        return filter_tool_descriptions(
            allowlist=self.current_agent.tools or None,
            denylist=self.current_agent.disallowed_tools or None,
        )

    def _load_skills(self, force: bool = False) -> None:
        if self._skills_loaded and not force:
            return

        # Remove previously loaded skill-tagged messages so they don't
        # accumulate across agent switches or skill re-loads.
        self.context.remove_system_by_marker("<!-- SKILL:")
        self.context.remove_system_by_marker("<!-- PROJECT_DOC -->")
        self.context.remove_system_by_marker("<!-- CDH_PROJECT -->")
        self._skills_loaded = True

        for skill in self._skill_loader.get_enabled():
            tagged = f"<!-- SKILL:{skill.name} -->\n{skill.content}"
            self.context.add_system(tagged)

        # Project-level single-file doc (AGENTS.md at workspace root)
        from onecode.agent.project_doc import load_project_doc
        project_doc = load_project_doc(self._workspace)
        if project_doc:
            self.context.add_system(f"<!-- PROJECT_DOC -->\n{project_doc}")

        # Load project .cdh/ state into context
        from onecode.agent.cdh_loader import CdhProjectLoader
        cdh_content = CdhProjectLoader.load_for_workspace(self._workspace)
        if cdh_content:
            self.context.add_system(f"<!-- CDH_PROJECT -->\n{cdh_content}")

    def _inject_project_context(self, project_name: str) -> None:
        if not project_name:
            return
        if self._project_context_loaded:
            return

        self._project_context_loaded = True
        self._project_config = {}

        context_parts = [
            f"Project: {project_name}",
            f"Platform: {self._project_config.get('platform', 'unknown')}",
        ]

        env_id = self._project_config.get("cloudbase", {}).get("envId", "")
        if env_id:
            context_parts.append(f"TCB EnvId: {env_id}")

        self.context.add_system("\n".join(context_parts))

    def _should_retrieve_codebase(self) -> bool:
        try:
            cfg = self.app.config.codebase
            return cfg.enabled and cfg.auto_retrieve
        except Exception:
            return False

    async def _get_codebase_engine(self):
        if self._codebase_engine is not None:
            return self._codebase_engine
        try:
            cfg = self.app.config.codebase
            if not cfg.enabled:
                return None
            from onecode.codebase import CodebaseEngine
            self._codebase_engine = CodebaseEngine(self._project_dir, cfg)
            await self._codebase_engine.ensure_indexed()
            return self._codebase_engine
        except Exception as e:
            logger.warning("Failed to init codebase engine: %s", e)
            return None

    async def chat(self, user_input: str) -> str:
        self._load_skills()

        project_name = getattr(self.app, "current_project", None) or ""
        if project_name:
            self._inject_project_context(project_name)

        self.context.add_user(user_input)

        self.context.config.model = self.app.current_model
        if self.context.should_compact():
            level = self.context.compact()
            if level not in ("none",):
                logger.info("Context compaction applied: %s", level)

        provider_cls = ProviderRegistry.get(self.app.current_provider)
        if not provider_cls:
            return f"Provider '{self.app.current_provider}' not available."

        config = self.app.config.providers.get(self.app.current_provider)
        if config is None:
            return f"Provider '{self.app.current_provider}' not configured."

        provider = provider_cls(
            api_key=config.api_key or "",
            endpoint=config.endpoint or None,
        )

        response = await provider.chat(
            self.context.get_context(),
            model=self.app.current_model,
        )

        self.context.add_assistant(response.content)
        self.iterations += 1
        self.total_tokens += response.usage.get("total_tokens", 0)
        return response.content

    def _parse_tool_calls(self, text: str) -> list[dict]:
        calls = []
        for match in TOOL_CALL_RE.finditer(text):
            name = match.group(1)
            call_id = match.group(2)
            raw_input = match.group(3).strip()
            try:
                parsed_input = json.loads(raw_input) if raw_input else {}
            except json.JSONDecodeError:
                parsed_input = {"raw": raw_input}
            calls.append({"name": name, "id": call_id, "input": parsed_input})
        return calls

    def _validate_edit(self, path: str) -> str | None:
        try:
            content = self.file_ops.read(path, 0, 0)
            if content and "error" not in str(content).lower():
                return None
            return f"Warning: File may not have been written correctly: {path}"
        except Exception as e:
            return f"Warning: Could not verify file: {e}"

    def _tool_category(self, name: str) -> str:
        """Map tool name to category for structured display."""
        from onecode.models.messages import get_tool_category
        return get_tool_category(name).value

    _TOOL_NAME_TO_PERM_KEY: dict[str, str] = {
        "Read": "read",
        "Write": "edit",
        "Edit": "edit",
        "Insert": "edit",
        "UndoEdit": "edit",
        "ApplyPatch": "edit",
        "Bash": "bash",
        "WebFetch": "webfetch",
        "WebSearch": "websearch",
        "Glob": "glob",
        "Grep": "grep",
        "List": "list",
        "Spawn": "task",
        "Agent": "task",
        "Skill": "skill",
        "codebase_search": "read",
        "TodoCreate": "todowrite",
        "TodoGet": "todowrite",
        "TodoList": "todowrite",
        "TodoUpdate": "todowrite",
        "TodoOutput": "todowrite",
        "TodoStop": "todowrite",
        "TodoClear": "todowrite",
    }

    def _check_tool_permission(self, name: str, inp: dict) -> str | None:
        """Unified agent-level permission check for all tools."""
        from onecode.agent.agents.types import AgentPermission
        # Enforce agent allow/deny lists at runtime. This is the runtime
        # safety net behind filter_tool_descriptions(): even if the LLM
        # still emits a tool the system prompt hid (e.g. TodoCreate in a
        # subagent, after context compaction re-introduced the name), the
        # call is denied here rather than leaking through.
        if not self.current_agent.tool_allowed(name):
            return json.dumps({"success": False, "error": f"{name} denied (disallowed for {self.current_agent.name})"})
        perm_key = self._TOOL_NAME_TO_PERM_KEY.get(name)
        if perm_key is None:
            return None
        tools_config = self.current_agent.get_tools_config()
        perm = tools_config.get(perm_key, AgentPermission.ALLOW)
        if perm == AgentPermission.DENY:
            return json.dumps({"success": False, "error": f"{name} denied"})
        if perm == AgentPermission.ASK:
            return json.dumps({"success": False, "error": f"{name} requires approval", "requires_approval": True})
        return None

    async def _execute_tool(self, tool_call: dict) -> dict:
        from onecode.agent.tools.registry import ToolCall as RegistryToolCall
        name = tool_call["name"]
        tid = tool_call["id"]
        inp = tool_call["input"]
        category = self._tool_category(name)
        base = {"tool_use_id": tid, "is_error": False, "category": category}
        try:
            denied = self._check_tool_permission(name, inp)
            if denied:
                return {**base, "content": denied, "is_error": True}

            call = RegistryToolCall(name=name, input=inp, tool_use_id=tid)
            result = await self._tool_registry.dispatch_async(
                call, cancel_check=lambda: self._cancelled,
            )

            # Handle SendMessage tracking
            if name == "SendMessage":
                msg_output = result.output if isinstance(result.output, dict) else {}
                self._last_user_msg = msg_output.get("message", "")
                return {**base, "content": json.dumps(result.output), "is_error": result.is_error}

            # Format output for backward compatibility
            output = self._format_tool_output(result)
            return {**base, "content": output, "is_error": result.is_error}
        except Exception as e:
            logger.exception(f"Tool execution error: {e}")
            return {**base, "content": f"Error: {safe_error_msg(e)}", "is_error": True}

    def _format_tool_output(self, result: RegistryToolResult) -> str:  # noqa: F821
        import json
        output = result.output
        if isinstance(output, str):
            return output
        try:
            return json.dumps(output)
        except (TypeError, ValueError):
            return str(output)

    async def cancel(self):
        """Cancel the current chat_stream turn and all in-flight subagents."""
        self._cancelled = True
        for child in self._child_engines:
            child._cancelled = True

    async def shutdown(self):
        """Release OS resources held by this engine (LSP, MCP, cron)."""
        self._cancelled = True
        for child in self._child_engines:
            child._cancelled = True
        self._lsp_tool.stop_all()
        await self._mcp.disconnect_all()
        self._cron_scheduler.stop_loop()

    def __del__(self):
        """Fallback cleanup on garbage collection."""
        self._lsp_tool.stop_all()
        self._cron_scheduler.stop_loop()

    async def chat_stream(self, user_input: str | list[dict]) -> AsyncIterator[StreamEvent | str]:
        self._load_skills()
        preview = user_input[:100] if isinstance(user_input, str) else f"[{len(user_input)} content blocks]"
        logger.info(f"chat_stream() called with user_input='{preview}'")

        project_name = getattr(self.app, "current_project", None) or ""
        if project_name:
            was_context_loaded = self._project_context_loaded
            self._inject_project_context(project_name)
            if not was_context_loaded:
                yield StreamEvent.text_delta(
                    f"\n📋 项目: {project_name}\n继续开发中...\n\n"
                )
        else:
            pass

        # Emit initial plan so the TUI Plan widget is mounted (or refreshed
        # to the current snapshot) at the start of every turn.  This is
        # required because the Plan widget only renders when an ``entries``
        # value arrives — without this, the widget never appears until the
        # agent happens to call a task tool.
        for event in self._emit_plan_update():
            yield event
        self._plan_dirty = False

        # ── Codebase auto-retrieval ──
        # Skipped entirely for subagent engines (see _disable_retrieval)
        # to avoid the 2.3s+ indexer loop and the per-chunk embedding httpx
        # calls that block the event loop and freeze streaming/cancel.
        if (
            isinstance(user_input, str)
            and self._should_retrieve_codebase()
            and not self._disable_retrieval
        ):
            try:
                engine = await self._get_codebase_engine()
                if engine:
                    chunks = await engine.retrieve(user_input)
                    ctx_text = engine.format_context(
                        chunks, max_tokens=self.app.config.codebase.max_chunk_tokens
                    )
                    if ctx_text:
                        if not self.context.replace_system_section("CODEBASE", ctx_text):
                            self.context.add_system(f"<!-- CODEBASE -->\n{ctx_text}")
            except Exception as e:
                logger.warning("Codebase retrieval failed: %s", e)

        # ── Long-term memory recall ──
        if (
            isinstance(user_input, str)
            and self._session
            and self.app.config.memory.enabled
            and self.app.config.memory.auto_recall
            and not self._disable_retrieval
        ):
            try:
                top_k = self.app.config.memory.top_k
                results = self._memory.search_memories(user_input, top_k=top_k)
                if results:
                    lines = ["## Relevant past memories"]
                    for r in results:
                        lines.append(r.content[:300])
                    ctx_text = "<!-- MEMORY -->\n" + "\n".join(lines)
                    if not self.context.replace_system_section("MEMORY", ctx_text):
                        self.context.add_system(ctx_text)
            except Exception as e:
                logger.warning("Memory recall failed: %s", e)

        self.context.add_user(user_input)

        # Plan gate: activate based on agent mode, not content heuristics.
        # Gate fires reactively when agent tries execution tools without a plan.
        self._plan_gate_mode = self._resolve_plan_gate_mode()

        self.context.config.model = self.app.current_model
        if self.context.should_compact():
            level = self.context.compact()
            if level not in ("none",):
                logger.info("Context compaction at turn start: %s", level)

        provider_name = self.app.current_provider
        model_name = self.app.current_model
        logger.info(f"Using provider='{provider_name}', model='{model_name}'")
        logger.info(
            "chat_stream engine state: project=%s agent=%s todos=%d context_msgs=%d ctx_tokens=%d",
            project_name or "(none)",
            self.current_agent.name if self.current_agent else "None",
            len(self._todo_manager.list_todos()),
            len(self.context.messages),
            self.context._token_count,
        )

        provider_cls = ProviderRegistry.get(provider_name)
        if not provider_cls:
            available = list(ProviderRegistry._registry.keys()) if hasattr(ProviderRegistry, '_registry') else "unknown"
            error_msg = f"Provider '{provider_name}' not available. Available: {available}"
            logger.error(error_msg)
            yield StreamEvent.error(error_msg)
            return

        config = self.app.config.providers.get(provider_name)
        if config is None:
            available = list(self.app.config.providers.keys())
            error_msg = f"Provider '{provider_name}' not configured. Available providers: {available}"
            logger.error(error_msg)
            yield StreamEvent.error(error_msg)
            return

        logger.info(f"Creating provider instance: {provider_cls.__name__}")
        provider_kwargs = dict(api_key=config.api_key or "", endpoint=config.endpoint or None)
        provider = provider_cls(**provider_kwargs)

        # If the provider supports native tool schemas (OpenAI/Anthropic/DeepSeek
        # etc.), strip the prose TOOL_DESCRIPTIONS from system context to save
        # tokens. The structured ``tools`` kwarg provides the same info.
        if not hasattr(provider, 'supports_native_tools') or provider.supports_native_tools():
            self._strip_agent_config_tool_descriptions()

        # Reset per-turn usage tracking
        self._turn_usages = []

        # Reset cancellation flag (adapter also resets it before calling)
        self._cancelled = False

        # ── Agent loop: 思考 → Todo → 行动 (per-Round) ──
        is_anthropic = provider.is_anthropic_style()
        max_turns = self.current_agent.max_turns or 10

        cot_phase_init = "<!-- REACT_PHASE -->\n## Round 1 — 思考 → Todo → 行动\n"
        if not self.context.replace_system_section("REACT_PHASE", cot_phase_init):
            self.context.add_system(cot_phase_init)

        for turn in range(max_turns):
            if self._cancelled:
                yield StreamEvent.text_delta("\n\n*Turn cancelled*\n\n")
                return

            # ── Thought Phase: update CoT reasoning guidance for this turn ──
            # Cleanup stale reminders that may have accumulated
            self.context.remove_system_by_marker("<!-- ROUTING_REMINDER -->")
            self.context.remove_system_by_marker("<!-- PLAN_REMINDER -->")
            # Inject (or refresh) a nudge that prioritizes any unfinished todos
            # from this session. The marker is replaced in-place so the context
            # stays bounded — the agent always sees the current open list.
            self._refresh_pending_todos_nudge()
            if turn > 0:
                self.context.replace_system_section(
                    "REACT_PHASE",
                    f"<!-- REACT_PHASE -->\n## Round {turn + 1} — 思考 → Todo → 行动\n",
                )

            self._pending_thinking_blocks = []

            self.context.config.model = self.app.current_model
            if self.context.should_compact():
                level = self.context.compact()
                if level not in ("none",):
                    logger.info("Context compaction at turn %d: %s", turn, level)

            turn_usage: dict[str, int] = {}
            response_text = ""
            tool_uses: list[dict] = []

            try:
                context_messages = self.context.get_context()
                logger.info(f"Calling provider.chat_stream_response (turn {turn+1})")
                self._streaming_used = False
                if self.on_text_chunk is not None:
                    _original_cb = self.on_text_chunk
                    def _stream_wrapper(text: str) -> None:
                        self._streaming_used = True
                        if self._cancelled:
                            raise TurnCancelledError()
                        _original_cb(text)
                    stream_cb = _stream_wrapper
                else:
                    stream_cb = None
                chat_response = await provider.chat_stream_response(
                    context_messages,
                    model=model_name,
                    on_text_chunk=stream_cb,
                    on_tool_call_delta=self.on_tool_call_delta,
                    tools=self._tool_registry.make_openai_schemas(),
                )
                response_text = chat_response.content
                tool_uses = chat_response.tool_uses
                if not tool_uses and (
                    "<minimax:tool_call>" in response_text
                    or _LEGACY_OPEN in response_text
                ):
                    parsed_uses, response_text, self._tool_id_counter = (
                        _extract_minimax_tool_uses(
                            response_text, id_start=self._tool_id_counter
                        )
                    )
                    legacy_uses, response_text, self._tool_id_counter = (
                        _extract_legacy_tool_uses(
                            response_text, id_start=self._tool_id_counter
                        )
                    )
                    tool_uses = parsed_uses + legacy_uses
                    if tool_uses:
                        logger.info(
                            "Extracted %d text tool uses (%d minimax, %d legacy) from response",
                            len(tool_uses), len(parsed_uses), len(legacy_uses),
                        )
                if chat_response.usage:
                    turn_usage = chat_response.usage
            except NotImplementedError:
                logger.info("chat_stream_response not supported, falling back to non-streaming chat()")
                try:
                    context_messages = self.context.get_context()
                    model_response = await provider.chat(
                        context_messages,
                        model=model_name,
                        tools=self._tool_registry.make_openai_schemas(),
                    )
                    response_text = model_response.get_text()
                    tool_uses = [
                        {"id": tu.id, "name": tu.name, "input": tu.input}
                        for cb in model_response.content
                        if cb.type == ContentBlockType.TOOL_USE and cb.tool_use
                        for tu in [cb.tool_use]
                    ]
                    if not tool_uses and (
                        "<minimax:tool_call>" in response_text
                        or _LEGACY_OPEN in response_text
                    ):
                        parsed_uses, response_text, self._tool_id_counter = (
                            _extract_minimax_tool_uses(
                                response_text, id_start=self._tool_id_counter
                            )
                        )
                        legacy_uses, response_text, self._tool_id_counter = (
                            _extract_legacy_tool_uses(
                                response_text, id_start=self._tool_id_counter
                            )
                        )
                        tool_uses = parsed_uses + legacy_uses
                        if tool_uses:
                            logger.info(
                                "Extracted %d text tool uses (%d minimax, %d legacy) from chat() fallback",
                                len(tool_uses), len(parsed_uses), len(legacy_uses),
                            )
                    if model_response.usage:
                        turn_usage = model_response.usage
                except Exception as e:
                    logger.exception(f"Error during chat() fallback turn {turn+1}: {e}")
                    yield StreamEvent.error(safe_error_msg(e))
                    break
            except TurnCancelledError:
                yield StreamEvent.text_delta("\n\n*Turn cancelled*\n\n")
                return
            except Exception as e:
                ctx_msgs = len(self.context.messages)
                ctx_tokens = self.context._token_count
                logger.exception(
                    f"Error during chat_stream_response turn {turn+1}: {e}\n"
                    f"  provider={provider_name} model={model_name} "
                    f"context_msgs={ctx_msgs} ctx_tokens={ctx_tokens}"
                )
                yield StreamEvent.error(f"Provider error (turn {turn+1}): {safe_error_msg(e)}")
                break

            # Check cancellation after provider call (covers non-streaming
            # responses and cases where on_text_chunk was never called).
            if self._cancelled:
                yield StreamEvent.text_delta("\n\n*Turn cancelled*\n\n")
                return

            # Track usage
            self._turn_usages.append(turn_usage)
            if turn_usage:
                self.total_tokens += turn_usage.get("total_tokens", 0)

            # Extract thinking blocks from response. In the streaming path
            # the adapter's _make_stream_callback already stripped <thinking>
            # markers from the text and routed them through self.on_thinking
            # (which appends to _pending_thinking_blocks). The non-streaming
            # fallback still has the markers inline, so we parse them here.
            thinking_blocks = list(self._pending_thinking_blocks)
            clean_text = response_text
            for match in THINKING_RE.finditer(response_text):
                tb = match.group(1)
                if tb not in thinking_blocks:
                    thinking_blocks.append(tb)
            if thinking_blocks or self._pending_thinking_blocks:
                clean_text = THINKING_RE.sub('', response_text).strip()
                if not self._streaming_used:
                    for tb in thinking_blocks:
                        yield StreamEvent.thinking(tb)

            # Log the raw model response so developers can verify the
            # model is actually emitting ``<thinking>`` markers (and not
            # bleeding planning prose into the visible answer).  Goes
            # to the onecode root logger → ~/.onecode/logs/onecode.log when
            # ``setup_logging(DEBUG)`` is in effect.
            logger.debug(
                "RAW_RESPONSE turn=%d text_len=%d first_200=%r "
                "thinking_blocks=%d tool_uses=%d streaming_used=%s",
                turn + 1,
                len(response_text),
                response_text[:200],
                len(thinking_blocks),
                len(tool_uses),
                self._streaming_used,
            )

            # Add assistant response to context with proper content blocks.
            # Persist thinking blocks so they survive session reload — the
            # TUI replays them as collapsible Thought widgets.
            if tool_uses or thinking_blocks:
                assistant_blocks: list = []
                for tb in thinking_blocks:
                    assistant_blocks.append({"type": "thinking", "thinking": tb})
                if clean_text:
                    assistant_blocks.append({"type": "text", "text": clean_text})
                for tu in tool_uses:
                    assistant_blocks.append({
                        "type": "tool_use",
                        "id": tu["id"],
                        "name": tu["name"],
                        "input": tu["input"],
                    })
                self.context.add_assistant(assistant_blocks)
            else:
                self.context.add_assistant(clean_text)

            self.iterations += 1

            # Always yield text content as TEXT_DELTA, regardless of tool uses.
            # Without this, subagent text is consumed silently when it also
            # emits tool calls — the text goes to context but never reaches
            # _spawn_subagent_async_streaming / the subagent_chunk stream.
            if not self._streaming_used and clean_text.strip():
                for i in range(0, len(clean_text), 12):
                    yield StreamEvent.text_delta(clean_text[i:i + 12])

            if not tool_uses:
                # ── Store conversation in long-term memory ──
                if self._session:
                    try:
                        conv_id = self._session.id
                        input_str = user_input if isinstance(user_input, str) else str(user_input)
                        self._memory.remember(
                            MemoryLayer.L0_CONVERSATION,
                            f"user: {input_str}\nassistant: {clean_text}",
                            {"conversation_id": conv_id},
                        )
                    except Exception as e:
                        logger.warning("Memory store failed: %s", e)

                # ── Force continuation if todos remain ──
                # After subagents complete, the LLM may stop calling tools
                # because the structured output strongly signals "done".
                # If there are still pending/in-progress todos, inject a
                # forceful continuation nudge and loop again instead of
                # exiting the turn loop.
                self._empty_tool_turns += 1
                if self._empty_tool_turns >= 3:
                    logger.warning(
                        "LLM produced %d consecutive empty turns with %d "
                        "remaining todos — breaking loop",
                        self._empty_tool_turns,
                        sum(1 for t in self._todo_manager.list_todos()
                            if t.get("status") in ("pending", "in_progress")),
                    )
                    break
                if self._has_pending_todos():
                    open_count = sum(
                        1 for t in self._todo_manager.list_todos()
                        if t.get("status") in ("pending", "in_progress")
                    )
                    logger.info(
                        "LLM stopped calling tools but %d pending todos remain — "
                        "injecting FORCE_CONTINUE nudge (empty_tool_turns=%d)",
                        open_count, self._empty_tool_turns,
                    )
                    # Auto-advance: since the LLM is stalled, find the next
                    # pending todo and inject a direct instruction.
                    next_todo = None
                    for t in self._todo_manager.list_todos():
                        if t.get("status") == "pending":
                            next_todo = t
                            break
                    if next_todo:
                        lines = [
                            "# Continue working",
                            "",
                            f"The next pending todo is `{next_todo['id']}`: "
                            f"{next_todo.get('subject', '')}",
                            "",
                            "Execute it now. Do NOT summarise or stop.",
                        ]
                        self.context.add_message(
                            "user",
                            [{"type": "text", "text": "\n".join(lines)}],
                        )
                    else:
                        lines = [
                            "<!-- FORCE_CONTINUE -->",
            "## CRITICAL: Unfinished todos detected",
            "You stopped without completing all planned todos.",
            "You MUST continue working:",
            "1. Call TodoUpdate(status=\"completed\") for any finished work.",
            "2. Then Spawn or execute the next pending todo.",
            "3. Repeat until ALL todos are Done.",
            "Do NOT stop. Do NOT summarise. Keep executing.",
                        ]
                        self.context.add_message(
                            "user",
                            [{"type": "text", "text": "\n".join(lines)}],
                        )
                    continue
                # No pending todos and no tool calls: work appears done.
                # Guard: if no todos were ever created after multiple rounds,
                # the agent may have done work without tracking it. Inject a
                # one-time confirmation prompt before giving the final break.
                all_todos = self._todo_manager.list_todos()
                if not all_todos and self.iterations > 1:
                    confirm_lines = [
                        "# Final check",
                        "",
                        "You haven't created any todos in this session. "
                        "Are you sure all work is complete?",
                        "",
                        "If work remains → `TodoCreate` and continue.",
                        "If done → output a visible summary of what you accomplished.",
                    ]
                    self.context.add_message(
                        "user",
                        [{"type": "text", "text": "\n".join(confirm_lines)}],
                    )
                    self._empty_tool_turns += 1
                    continue
                break

            # Emit ToolEvents (Clawd-Code pattern) and StreamEvents for TUI
            for tu in tool_uses:
                self._notify_event(ToolEvent(
                    kind="tool_use",
                    tool_name=tu["name"],
                    tool_input=tu["input"],
                    tool_use_id=tu["id"],
                ))
                yield StreamEvent.tool_call_start(tu["name"], tu["id"])
            for tu in tool_uses:
                yield StreamEvent.tool_call_complete(tu["id"], tu["name"], tu["input"])

            for tu in tool_uses:
                if self._cancelled:
                    yield StreamEvent.text_delta("\n\n*Turn cancelled*\n\n")
                    return
                logger.info(f"Executing tool: {tu['name']} (id={tu['id']})")

                # Spawn tool: forward subagent text deltas to the TUI as
                # subagent_chunk events so the SubAgent widget actually has
                # content to render.  The Spawn tool's spec is (agent_type,
                # prompt); we read them from the tool input.
                if tu["name"] == "Spawn":
                    # Permission check
                    denied = self._check_tool_permission("Spawn", tu["input"])
                    if denied:
                        result = {
                            "tool_use_id": tu["id"],
                            "is_error": True,
                            "category": "task",
                            "content": denied,
                        }
                    else:
                        subagent_type = tu["input"].get("agent_type", "general")
                        subagent_prompt = tu["input"].get("prompt", "")
                        _sp_id = tu["id"]
                        _sp_bytes_fwd = 0
                        _sp_chunk_count = 0
                        logger.debug(
                            "[SPAWN-PARENT %s] start subagent_type=%s prompt_len=%d "
                            "tool_id=%s cancelled=%s",
                            _sp_id, subagent_type, len(subagent_prompt),
                            _sp_id, self._cancelled,
                        )
                        is_failed = False
                        error_msg = ""
                        yield StreamEvent.subagent_start(subagent_type, tu["id"], subagent_prompt)
                        accumulated: list[str] = []
                        try:
                            async for sub_event, sub_text in self._spawn_subagent_async_streaming(
                                subagent_type, subagent_prompt, subagent_id=tu["id"]
                            ):
                                _sp_chunk_count += 1
                                if self._cancelled:
                                    logger.debug(
                                        "[SPAWN-PARENT %s] cancelled mid-iter "
                                        "chunk=%d → break", _sp_id, _sp_chunk_count)
                                    break
                                if sub_event.type == StreamEventType.SUBAGENT_END:
                                    if hasattr(sub_event, "subagent_status") and sub_event.subagent_status == "failed":
                                        is_failed = True
                                        error_msg = sub_event.subagent_error or ""
                                    logger.debug(
                                        "[SPAWN-PARENT %s] recv SUBAGENT_END "
                                        "status=%s → continue",
                                        _sp_id, getattr(sub_event, "subagent_status", "?"),
                                    )
                                    continue  # 修复 Bug 1: 不 append final combined text（避免文本重复）
                                if sub_event.type == StreamEventType.SUBAGENT_THINKING:
                                    yield StreamEvent.subagent_thinking(tu["id"], sub_text)
                                    continue
                                # Structured subagent tool events: forward as-is
                                # (they already carry subagent_id=tu["id"]) so the
                                # ACP emits tool_call/tool_call_update sessionUpdates
                                # tagged with subagentId and the TUI renders real
                                # ToolCall cards inside the SubAgent widget.
                                if sub_event.type in (
                                    StreamEventType.SUBAGENT_TOOL_CALL,
                                    StreamEventType.SUBAGENT_TOOL_RESULT,
                                ):
                                    yield sub_event
                                    continue
                                if not sub_text:
                                    continue
                                accumulated.append(sub_text)
                                _sp_bytes_fwd += len(sub_text)
                                if _sp_chunk_count <= 5 or _sp_chunk_count % 50 == 0:
                                    logger.debug(
                                        "[SPAWN-PARENT %s] fwd chunk#%d bytes=%d "
                                        "total=%d",
                                        _sp_id, _sp_chunk_count, len(sub_text),
                                        _sp_bytes_fwd,
                                    )
                                yield StreamEvent.subagent_chunk(tu["id"], sub_text)
                        except asyncio.CancelledError:
                            logger.debug(
                                "[SPAWN-PARENT %s] CancelledError → subagent_end "
                                "failed=cancelled + re-raise", _sp_id)
                            yield StreamEvent.subagent_end(
                                tu["id"],
                                agent_type=subagent_type,
                                status="failed",
                                error="cancelled",
                            )
                            raise
                        logger.debug(
                            "[SPAWN-PARENT %s] subagent done fwd_chunks=%d "
                            "bytes_fwd=%d is_failed=%s err=%r → yield subagent_end",
                            _sp_id, _sp_chunk_count, _sp_bytes_fwd, is_failed,
                            error_msg[:80],
                        )
                        yield StreamEvent.subagent_end(
                            tu["id"],
                            agent_type=subagent_type,
                            status="failed" if is_failed else "completed",
                            error=error_msg,
                        )
                        raw_output = "".join(accumulated)
                        logger.debug(
                            "[SPAWN-PARENT %s] formatting result raw_len=%d "
                            "is_failed=%s", _sp_id, len(raw_output), is_failed,
                        )
                        formatted = self._format_subagent_output(
                            subagent_type, subagent_prompt, raw_output
                        ) if not is_failed else (
                            f"SUMMARY:\nSub-agent failed with error: {error_msg}\n\n"
                            "CHANGES:\nNone.\n\nEVIDENCE:\nNone.\n\nRISKS:\nNone.\n\n"
                            f"BLOCKERS:\n{error_msg}"
                        )
                        result = {
                            "tool_use_id": tu["id"],
                            "is_error": is_failed,  # 修复 Bug 2: 子智能体失败时 is_error=True
                            "category": "task",
                            "content": formatted,
                            "raw_content": raw_output,
                        }
                        # Auto-advance todo after subagent completes
                        if not is_failed:
                            self._auto_advance_after_spawn(subagent_prompt)
                elif (self._plan_gate_mode != "off"
                      and not self._todo_manager.list_todos()
                      and tu["name"] in _EXECUTION_TOOLS
                      and self._plan_gate_first_turn()):
                    if self._plan_gate_mode == "hard":
                        result = {
                            "tool_use_id": tu["id"],
                            "is_error": True,
                            "category": "todo",
                            "content": json.dumps({
                                "success": False,
                                "error": (
                                    "Plan required. You are in plan mode (ReAct: Thought → Action → Observation). "
                                    "Before using execution tools, create a todo plan via `TodoCreate()`. "
                                    "Choose the right granularity:\n"
                                    "- Each todo = one focused unit of work (file, function, or concern).\n"
                                    "- Set `addBlockedBy` on dependent todos to express the DAG.\n"
                                    "- For complex multi-step work, mark the todo with "
                                    "`metadata={\"delegate_to\": \"general\"}` to indicate it should be "
                                    "executed by a `Spawn` subagent rather than direct tool calls.\n"
                                    "Create ALL todos upfront, present the plan for user review, "
                                    "and only then proceed to execute."
                                ),
                            }),
                        }
                    else:
                        # Soft gate: execute but inject a routing reminder for next turn
                        self.context.add_system(
                            "<!-- PLAN_REMINDER -->\n"
                            "## Routing Decision\n"
                            "Every task is a todo: create it with `TodoCreate` first (it "
                            "persists to .cdh/todos.json and shows in the sidebar Plan).\n"
                            "Then route EXECUTION by complexity:\n\n"
                            "**Simple / single-step** → execute the todo directly with "
                            "`Read`/`Edit`/`Bash`, then `TodoUpdate(status=\"completed\")`.\n\n"
                            "**Complex / multi-step / needs isolated context** → "
                            "`Spawn(agent_type, prompt)` delegates to a focused subagent; "
                            "on return, `TodoUpdate(status=\"completed\")`.\n\n"
                            "**Plan vs execution**: TodoCreate = planning (always); "
                            "Spawn = execution delegation (complex only). They are not "
                            "alternatives — Spawn executes a todo, it does not replace one.\n"
                        )
                        result = await self._execute_tool(tu)
                else:
                    result = await self._execute_tool(tu)
                    # Routing: track direct execution tool use → nudge routing decision
                    if tu["name"] in _EXECUTION_TOOLS:
                        self._direct_execution_count += 1
                        if self._direct_execution_count >= 2:
                            self.context.add_system(
                                "<!-- ROUTING_REMINDER -->\n"
                                "You've used direct execution tools repeatedly. Pause and decide:\n"
                                "- Is this work tracked by a todo? If not, `TodoCreate` first.\n"
                                "- If the todo is a single-step trivial change → continue, then "
                                "`TodoUpdate(status=\"completed\")`.\n"
                                "- If this work involves >1 tool call, multiple files, or "
                                "research → STOP direct execution and delegate via "
                                "`Spawn(agent_type=\"general\", prompt=\"...\")` instead. The "
                                "subagent isolates context and returns a structured summary; "
                                "then mark the todo completed."
                            )
                result_str = str(result.get("content", ""))
                is_error = result.get("is_error", False)
                category = result.get("category", "unknown")
                # For Spawn tools, use raw subagent output for TUI display
                # (no SUMMARY/CHANGES/… structured wrapper)
                tui_content = str(result.get("raw_content", result_str))

                # Handle SendMessage — user-visible only, skip from LLM context
                if tu["name"] == "SendMessage":
                    try:
                        parsed = json.loads(result_str) if result_str else {}
                        msg = parsed.get("message", "") if isinstance(parsed, dict) else ""
                        if msg:
                            self._last_user_msg = msg
                            yield StreamEvent.text_delta(f"\n💬 {msg}\n")
                    except (json.JSONDecodeError, ValueError):
                        pass
                    self._notify_event(ToolEvent(
                        kind="tool_result",
                        tool_name="SendMessage",
                        tool_use_id=tu["id"],
                        tool_output={"message": self._last_user_msg},
                    ))
                    continue

                # Handle AskUser — trigger user interaction dialog, don't add to LLM context yet
                if tu["name"] == "AskUser":
                    parsed = json.loads(result_str) if result_str else {}
                    question = parsed.get("question", "") if isinstance(parsed, dict) else ""
                    options = parsed.get("options", []) if isinstance(parsed, dict) else []
                    questions = parsed.get("questions", []) if isinstance(parsed, dict) else []

                    # Check for auto-default on single question + single option
                    if not questions and len(options) == 1 and options[0].get("default"):
                        default_val = options[0]["value"]
                        self._pending_approval = None
                        yield StreamEvent.tool_result(
                            call_id=tu["id"],
                            content=json.dumps({"answer": default_val}),
                        )
                        continue

                    # Auto-default for multi-question: skip questions that have
                    # a single option with default=true
                    if questions:
                        auto_answers = {}
                        remaining = []
                        for i, q in enumerate(questions):
                            qopts = q.get("options", [])
                            if len(qopts) == 1 and qopts[0].get("default"):
                                auto_answers[str(i)] = qopts[0]["value"]
                            else:
                                remaining.append(q)
                        if not remaining:
                            self._pending_approval = None
                            yield StreamEvent.tool_result(
                                call_id=tu["id"],
                                content=json.dumps({"answers": auto_answers}),
                            )
                            continue
                        questions = remaining

                    has_questions = bool(questions)
                    self._pending_approval = {"tool_call": tu, "category": category, "ask_user": True}
                    if has_questions:
                        yield StreamEvent.ask_user(
                            call_id=tu["id"],
                            action="AskUser",
                            question="",  # not used when questions is present
                            context=result_str,
                            options=[],
                            questions=questions,
                            action_type="ask_user",
                        )
                    else:
                        yield StreamEvent.ask_user(
                            call_id=tu["id"],
                            action="AskUser",
                            question=question,
                            context=result_str,
                            options=options,
                            action_type="ask_user",
                        )
                    continue

                # Detect ASK permission denial
                requires_approval = False
                try:
                    parsed = json.loads(result_str) if result_str else {}
                    requires_approval = isinstance(parsed, dict) and parsed.get("requires_approval", False)
                except (json.JSONDecodeError, ValueError):
                    pass

                if requires_approval:
                    self._pending_approval = {"tool_call": tu, "category": category}
                    self._notify_event(ToolEvent(
                        kind="tool_result",
                        tool_name=tu["name"],
                        tool_use_id=tu["id"],
                        is_error=True,
                        error="Requires approval",
                    ))
                    yield StreamEvent.ask_user(
                        call_id=tu["id"],
                        action=tu["name"],
                        question=f"Approve {tu['name']} operation?",
                        context=result_str,
                        action_type=tu["name"].lower(),
                        path=tu["input"].get("path", ""),
                        command=tu["input"].get("command", "")[:200],
                    )
                    # Generator resumes here after approval. The approved tool
                    # may have mutated todos (e.g. TodoUpdate via resolve_approval),
                    # flushing _plan_dirty so the TUI stays in sync.
                    if self._plan_dirty:
                        for event in self._emit_plan_update():
                            yield event
                        self._plan_dirty = False
                else:
                    from onecode.models.messages import ToolCategory as MsgToolCategory
                    try:
                        result_cat = MsgToolCategory(category)
                    except ValueError:
                        result_cat = MsgToolCategory.UNKNOWN
                    self._notify_event(ToolEvent(
                        kind="tool_result",
                        tool_name=tu["name"],
                        tool_output=result_str,
                        tool_use_id=tu["id"],
                        is_error=is_error,
                    ))
                    yield StreamEvent.tool_result(
                        call_id=tu["id"],
                        content=tui_content,
                        is_error=is_error,
                        category=result_cat,
                    )
                    # Add structured tool_result to LLM context
                    if is_anthropic:
                        self.context.add_tool_result(tu["id"], result_str, is_error)
                    else:
                        self.context.add_message(
                            "tool",
                            [{"type": "tool_result", "tool_use_id": tu["id"], "content": result_str, "is_error": is_error}],
                            name=tu["id"],
                        )
                    # Emit plan update when tasks/todos changed.  Any
                    # mutating path through TodoManager flips
                    # ``_plan_dirty`` via the ``on_change`` callback, so we
                    # do not need to enumerate tool names here.
                    if self._plan_dirty:
                        for event in self._emit_plan_update():
                            yield event
                        self._plan_dirty = False

            # Tools were called this turn — reset the empty-turn counter
            self._empty_tool_turns = 0

            if self._cancelled:
                yield StreamEvent.text_delta("\n\n*Turn cancelled*\n\n")
                return

        usage_summary = ", ".join(
            f"turn {i+1}: {u.get('total_tokens', '?')} tokens"
            for i, u in enumerate(self._turn_usages) if u
        )
        logger.info(f"Chat stream complete after {self.iterations} round(s). Usage: [{usage_summary}]")

        # ── Final summary fallback ──
        # If the last round had no visible text (all reasoning was inside
        # <thinking>), emit a deterministic summary so the user always sees
        # a completion report — no extra LLM round-trip needed.
        if not self._cancelled:
            last_msg = self.context.messages[-1] if self.context.messages else None
            has_visible = False
            if last_msg and last_msg.get("role") == "assistant":
                content = last_msg.get("content", "")
                if isinstance(content, str):
                    has_visible = bool(content.strip())
                elif isinstance(content, list):
                    has_visible = any(
                        isinstance(block, dict)
                        and block.get("type") == "text"
                        and block.get("text", "").strip()
                        for block in content
                    )
            if not has_visible:
                summary = self._build_completion_summary()
                yield StreamEvent.text_delta(summary)

    def has_pending_approval(self) -> bool:
        """Check if there's a pending approval request from ASK permission."""
        return self._pending_approval is not None

    async def resolve_approval(self, approved: bool, answer: str = "") -> dict | None:
        """Execute the pending action if approved, or return denial.

        For AskUser, ``answer`` is the user's free-text response.

        Returns the tool result dict, or None if no pending approval.
        """
        from onecode.agent.agents.types import AgentPermission
        if not self._pending_approval:
            return None
        
        tc = self._pending_approval["tool_call"]
        is_ask_user = self._pending_approval.get("ask_user", False)
        self._pending_approval = None

        # Handle AskUser — return user's answer as tool result
        if is_ask_user:
            if not approved:
                return {
                    "tool_use_id": tc["id"],
                    "content": json.dumps({"answer": "", "error": "User cancelled"}),
                    "is_error": True,
                    "category": tc.get("category", "unknown"),
                }
            # answer is a JSON string when multi-question, plain text otherwise
            try:
                parsed = json.loads(answer)
                is_structured = isinstance(parsed, dict) or isinstance(parsed, list)
            except (json.JSONDecodeError, TypeError):
                is_structured = False
            if is_structured:
                return {
                    "tool_use_id": tc["id"],
                    "content": json.dumps({"answers": parsed}),
                    "is_error": False,
                    "category": tc.get("category", "unknown"),
                }
            return {
                "tool_use_id": tc["id"],
                "content": json.dumps({"answer": answer}),
                "is_error": False,
                "category": tc.get("category", "unknown"),
            }
        
        if not approved:
            return {
                "tool_use_id": tc["id"],
                "content": json.dumps({"success": False, "error": "User denied the operation"}),
                "is_error": True,
                "category": tc.get("category", "unknown"),
            }
        
        perm_key = self._TOOL_NAME_TO_PERM_KEY.get(tc["name"])
        if perm_key is None:
            return await self._execute_tool(tc)

        attr_name = f"permission_{perm_key}"
        saved = getattr(self.current_agent, attr_name)
        try:
            setattr(self.current_agent, attr_name, AgentPermission.ALLOW)
            return await self._execute_tool(tc)
        finally:
            setattr(self.current_agent, attr_name, saved)

    def _reset_react_state(self) -> None:
        """Reset ReAct loop state for a fresh cycle."""
        self._react_phase = "thought"
        self._direct_execution_count = 0
        self._empty_tool_turns = 0
        self._plan_gate_fired = False
        # Invalidate the plan-emit dedupe cache so the next chat_stream
        # always produces a fresh snapshot for the TUI.
        self._last_emitted_plan = ()
        self.context.remove_system_by_marker("<!-- REACT_PHASE -->")
        self.context.remove_system_by_marker("<!-- ROUTING_REMINDER -->")
        self.context.remove_system_by_marker("<!-- PENDING_TODOS -->")

    def reset(self):
        self.context.reset()
        self.iterations = 0
        self.total_tokens = 0
        self._turn_usages = []
        self._skills_loaded = False
        self._project_context_loaded = False
        self._skill_loader.invalidate_cache()
        self._reset_react_state()

    def status(self) -> str:
        return (
            f"Agent: {self.current_agent.name}\n"
            f"Iterations: {self.iterations}\n"
            f"Total tokens: {self.total_tokens}\n"
            f"Context: {self.context.info()}"
        )

    def read_file(self, path: str, offset: int = 0, limit: int = 0) -> str:
        if self.current_agent.permission_read == AgentPermission.DENY:
            return "Read denied"
        return self.file_ops.read(path, offset, limit)

    def write_file(self, path: str, content: str) -> dict:
        if self.current_agent.permission_edit == AgentPermission.DENY:
            return {"success": False, "error": "Edit denied"}
        if self.current_agent.permission_edit == AgentPermission.ASK:
            return {"success": False, "error": "Edit requires approval", "requires_approval": True}
        return self.file_ops.write(path, content)

    def edit_file(self, path: str, old: str, new: str) -> dict:
        if self.current_agent.permission_edit == AgentPermission.DENY:
            return {"success": False, "error": "Edit denied"}
        if self.current_agent.permission_edit == AgentPermission.ASK:
            return {"success": False, "error": "Edit requires approval", "requires_approval": True}
        return self.file_ops.edit(path, old, new)

    def glob_files(self, pattern: str) -> list[str]:
        return self.file_ops.glob(pattern)

    def grep_files(self, pattern: str, include: str = None) -> list[str]:
        return self.file_ops.grep(pattern, include)

    def list_dir(self, path: str = ".") -> list[dict]:
        return self.file_ops.list(path)

    def exec_shell(self, cmd: str, timeout: int = 60) -> dict:
        if self.current_agent.permission_bash == AgentPermission.DENY:
            return {"success": False, "error": "Bash denied"}
        if self.current_agent.permission_bash == AgentPermission.ASK:
            return {"success": False, "error": "Bash requires approval", "requires_approval": True}
        return self.shell.exec(cmd, timeout=timeout)

    def web_fetch(self, url: str, prompt: str = None) -> str:
        if self.current_agent.permission_webfetch == AgentPermission.DENY:
            return "WebFetch denied"
        from onecode.agent.tools.web_tools import webfetch
        return webfetch(url, prompt)

    def web_search(self, query: str, num_results: int = 5) -> str:
        if self.current_agent.permission_websearch == AgentPermission.DENY:
            return "WebSearch denied"
        from onecode.agent.tools.web_tools import websearch
        return websearch(query, num_results)

    async def _spawn_subagent_async(self, agent_type: str, prompt: str) -> str:
        """Spawn a sub-agent with streaming-like output.

        Uses chat_stream to get structured output that the ChatPanel
        can parse for professional rendering.
        """
        parts: list[str] = []
        async for _event, text in self._spawn_subagent_async_streaming(agent_type, prompt):
            parts.append(text)
        result = "".join(parts)
        return self._format_subagent_output(agent_type, prompt, result)

    async def _spawn_subagent_async_streaming(
        self, agent_type: str, prompt: str, subagent_id: str = ""
    ) -> AsyncIterator[tuple[StreamEvent, str]]:
        """Streaming variant of :meth:`_spawn_subagent_async`.

        Yields ``(event, text)`` pairs so the caller (typically the Task-tool
        path in :meth:`chat_stream`) can forward each text delta as a
        ``subagent_chunk`` notification on the ACP wire.

        Inherits project context and skills from the parent
        engine so the subagent does not start from a blank slate.
        """
        # Depth check: subagents are leaf nodes (max depth = 1).
        if self._subagent_depth >= _MAX_SUBAGENT_DEPTH:
            err = "Subagent cannot spawn nested subagents (max depth=1)"
            yield (StreamEvent.subagent_end(
                "", agent_type=agent_type, status="failed", error=err,
            ), err)
            return

        sub_engine = AgentEngine(self.app, project_dir=self._project_dir, perm_store=self._perm_store)

        sub_engine._subagent_depth = self._subagent_depth + 1

        # Inherit parent context: project info (but NOT full skill content,
        # which contains Master Orchestrator instructions that conflict with
        # the subagent role). The subagent's own _load_skills() will load
        # only non-conflicting reference info via its own SkillLoader.
        sub_engine._project_context_loaded = self._project_context_loaded
        sub_engine._project_config = dict(self._project_config)
        sub_engine._skills_loaded = False

        # Inherit the parent's already-built codebase engine so the subagent
        # does NOT re-run the full project index (CodebaseIndexer.index()
        # is a synchronous chunk loop that would otherwise block the event
        # loop for the duration of indexing and freeze streaming/cancel).
        # Sharing the instance also avoids duplicate SQLite writes.
        sub_engine._codebase_engine = self._codebase_engine
        logger.debug(
            "[SA-STREAM %s] inheriting codebase_engine from parent: %s",
            agent_type, "shared" if self._codebase_engine is not None else "none",
        )

        # CRITICAL: disable codebase auto-retrieval + memory recall inside
        # the subagent.  Production logs prove that every Spawn hung here:
        # the subagent's ``chat_stream`` re-ran ``CodebaseIndexer.index()``
        # (a 2.3–2.6s synchronous loop, no await yield points) and then
        # ``CodebaseRetriever._retrieve_embedding()`` issued one ``httpx``
        # POST per chunk (30s timeout each, no effective cap), so a 148-
        # chunk project could block the event loop for ~minutes — during
        # which ``on_text_chunk`` never fires (no stream output) and
        # ``CancelledError`` injected by ``prompt_task.cancel()`` cannot
        # propagate (cannot be stopped).  A subagent executes a specific
        # prompt handed down by the parent; it does not need project-level
        # codebase seeding or memory recall.
        sub_engine._disable_retrieval = True
        logger.debug(
            "[SA-STREAM %s] set _disable_retrieval=True (subagent skips "
            "codebase auto-retrieval + memory recall)", agent_type,
        )

        # Do NOT propagate parent TUI-facing callbacks to the sub_engine.
        # - on_tool_call_delta: would fire the ACP's _on_tool_call_delta for
        #   the subagent's inner tools (Read/Bash/...), leaking their NAMES
        #   into the MAIN conversation as orphaned in_progress cards while
        #   the RESULT only reaches the SubAgent widget via the stream path
        #   below (tool_call_start/tool_result -> text_delta -> subagent_chunk).
        # - on_thinking: would append subagent thinking into the PARENT's
        #   _pending_thinking_blocks, polluting the parent's persisted session.
        # The subagent's tool calls/thinking are already relayed to the
        # SubAgent widget via SUBAGENT_CHUNK / SUBAGENT_THINKING (see the
        # consumer loop below). on_event is left propagated: the ACP does
        # not wire it, so it is None on the parent and a no-op here.
        if self.on_event is not None:
            sub_engine.on_event = self.on_event

        # Apply the requested agent_type's config (role description,
        # response-style / <thinking> tags, tool allow/deny list, REACT_CYCLE)
        # as the AGENT_CONFIG system section.
        sub_engine.set_agent(agent_type)

        # Track child so parent cancellation cascades
        self._child_engines.append(sub_engine)

        # ── Real-time streaming via asyncio.Queue ──
        # on_text_chunk puts provider tokens into the queue as they arrive,
        # and a background task puts chat_stream events into the same queue.
        # The main loop reads from the queue and yields (event, text) pairs,
        # giving the TUI live subagent output instead of "等待输出".
        _queue: asyncio.Queue[tuple[str, object]] = asyncio.Queue()
        _sa_log_prefix = f"[SA-STREAM {agent_type} depth={self._subagent_depth + 1}]"
        _sa_total_bytes = 0
        _sa_chunk_count = 0
        _sa_text_count = 0
        _sa_first_byte_logged = False

        def _on_subagent_text(text: str) -> None:
            nonlocal _sa_total_bytes, _sa_text_count, _sa_first_byte_logged
            try:
                _queue.put_nowait(("text", text))
                _sa_text_count += 1
                _sa_total_bytes += len(text)
                if not _sa_first_byte_logged:
                    _sa_first_byte_logged = True
                    logger.debug(
                        "%s on_text_chunk FIRST token bytes=%d (text_count so far=%d)",
                        _sa_log_prefix, len(text), _sa_text_count,
                    )
                if _sa_text_count % 20 == 0:
                    logger.debug(
                        "%s on_text_chunk progress text_calls=%d total_bytes=%d "
                        "queued=%d",
                        _sa_log_prefix, _sa_text_count, _sa_total_bytes,
                        _queue.qsize(),
                    )
            except Exception as e:
                logger.warning("%s on_text_chunk queue.put failed: %s", _sa_log_prefix, e)

        sub_engine.on_text_chunk = _on_subagent_text
        logger.debug("%s wiring on_text_chunk → queue (sub_engine id=%x)",
                     _sa_log_prefix, id(sub_engine))

        async def _run_chat_stream() -> None:
            logger.debug("%s _run_chat_stream task started", _sa_log_prefix)
            try:
                async for chunk in sub_engine.chat_stream(prompt):
                    await _queue.put(("event", chunk))
            except asyncio.CancelledError:
                logger.debug("%s _run_chat_stream CancelledError → queue(cancelled)",
                             _sa_log_prefix)
                await _queue.put(("cancelled", None))
            except Exception as e:
                logger.exception("%s _run_chat_stream exception: %s", _sa_log_prefix, e)
                await _queue.put(("error", e))
            finally:
                logger.debug(
                    "%s _run_chat_stream finally → queue(done) text=%d bytes=%d "
                    "chunk_events=%d",
                    _sa_log_prefix, _sa_text_count, _sa_total_bytes, _sa_chunk_count,
                )
                await _queue.put(("done", None))

        _stream_task = asyncio.create_task(_run_chat_stream())
        logger.debug("%s created _stream_task id=%x cancelled_flag=%s",
                     _sa_log_prefix, id(_stream_task), self._cancelled)

        parts: list[str] = []
        _streamed_via_text = False  # True once on_text_chunk has delivered tokens

        try:
            logger.debug("%s entering queue.get() consumer loop", _sa_log_prefix)
            while True:
                item_type, item = await _queue.get()
                _sa_chunk_count += 1
                if _sa_chunk_count <= 5 or _sa_chunk_count % 50 == 0:
                    logger.debug(
                        "%s queue.get() #%d type=%s cancelled_flag=%s qsize=%d "
                        "text=%d bytes=%d",
                        _sa_log_prefix, _sa_chunk_count, item_type,
                        self._cancelled, _queue.qsize(), _sa_text_count,
                        _sa_total_bytes,
                    )

                if item_type == "text":
                    _streamed_via_text = True
                    parts.append(item)
                    yield (StreamEvent.text_delta(item), item)

                elif item_type == "event":
                    chunk = item
                    if isinstance(chunk, StreamEvent):
                        if chunk.type == StreamEventType.TEXT_DELTA and chunk.text:
                            # Skip TEXT_DELTA if tokens were already streamed
                            # in real-time via on_text_chunk (avoids doubles).
                            if not _streamed_via_text:
                                if _sa_chunk_count <= 5:
                                    logger.debug(
                                        "%s TEXT_DELTA via event path (no "
                                        "streamed_via_text) bytes=%d",
                                        _sa_log_prefix, len(chunk.text),
                                    )
                                parts.append(chunk.text)
                                yield (chunk, chunk.text)
                            else:
                                if _sa_chunk_count <= 3:
                                    logger.debug(
                                        "%s TEXT_DELTA skipped (already "
                                        "streamed_via_text) bytes=%d",
                                        _sa_log_prefix, len(chunk.text),
                                    )
                        elif chunk.type == StreamEventType.THINKING and chunk.thinking:
                            logger.debug("%s THINKING event bytes=%d",
                                         _sa_log_prefix, len(chunk.thinking))
                            yield (chunk, chunk.thinking)
                        elif chunk.type == StreamEventType.TOOL_CALL_START:
                            logger.debug("%s TOOL_CALL_START tool=%s",
                                         _sa_log_prefix, chunk.tool_name)
                            yield (StreamEvent.subagent_tool_call(
                                subagent_id, "start", chunk.tool_id,
                                chunk.tool_name, chunk.tool_category,
                            ), "")
                        elif chunk.type == StreamEventType.TOOL_CALL_COMPLETE:
                            logger.debug("%s TOOL_CALL_COMPLETE tool=%s",
                                         _sa_log_prefix, chunk.tool_name)
                            yield (StreamEvent.subagent_tool_call(
                                subagent_id, "complete", chunk.tool_id,
                                chunk.tool_name, chunk.tool_category,
                                chunk.tool_args,
                            ), "")
                        elif chunk.type == StreamEventType.TOOL_RESULT:
                            logger.debug("%s TOOL_RESULT tool=%s",
                                         _sa_log_prefix, chunk.tool_name)
                            yield (StreamEvent.subagent_tool_result(
                                subagent_id, chunk.tool_id, chunk.tool_name,
                                chunk.result_content, chunk.result_is_error,
                                chunk.result_category,
                            ), "")
                        elif chunk.type == StreamEventType.ERROR:
                            logger.debug("%s ERROR event msg=%s",
                                         _sa_log_prefix, chunk.error_message)
                            text = f"\n[Error: {chunk.error_message}]\n"
                            yield (StreamEvent.text_delta(text), text)
                    else:
                        if chunk:
                            parts.append(chunk)

                elif item_type == "done":
                    logger.debug("%s queue.get()=done → break loop", _sa_log_prefix)
                    break

                elif item_type == "cancelled":
                    logger.debug(
                        "%s queue.get()=cancelled → yield subagent_end "
                        "failed=cancelled", _sa_log_prefix)
                    yield (StreamEvent.subagent_end(
                        "", agent_type=agent_type, status="failed", error="cancelled",
                    ), "")
                    return

                elif item_type == "error":
                    logger.exception("%s queue.get()=error: %s", _sa_log_prefix, item)
                    err_text = (
                        f"SUMMARY:\nSub-agent failed with error: {item}\n\n"
                        "CHANGES:\nNone.\n\nEVIDENCE:\nNone.\n\nRISKS:\nNone.\n\n"
                        f"BLOCKERS:\n{item}"
                    )
                    yield (StreamEvent.subagent_end(
                        "", agent_type=agent_type, status="failed", error=str(item),
                    ), err_text)
                    return

        except asyncio.CancelledError:
            logger.debug("%s consumer loop CancelledError → subagent_end", _sa_log_prefix)
            # Parent cancelled — emit subagent_end so the TUI widget
            # transitions out of "running", then re-raise.
            yield (StreamEvent.subagent_end(
                "", agent_type=agent_type, status="failed", error="cancelled",
            ), "")
            raise
        finally:
            logger.debug(
                "%s consumer finally: stream_task.done=%s cancelled_flag=%s "
                "text=%d bytes=%d chunk_events=%d",
                _sa_log_prefix, _stream_task.done(), self._cancelled,
                _sa_text_count, _sa_total_bytes, _sa_chunk_count,
            )
            if not _stream_task.done():
                logger.debug("%s finally: cancelling _stream_task (still running)",
                             _sa_log_prefix)
                _stream_task.cancel()
                try:
                    logger.debug("%s finally: awaiting _stream_task ...",
                                 _sa_log_prefix)
                    await _stream_task
                    logger.debug("%s finally: await _stream_task returned cleanly",
                                 _sa_log_prefix)
                except asyncio.CancelledError:
                    logger.debug("%s finally: await _stream_task CancelledError",
                                 _sa_log_prefix)
                except Exception as e:
                    logger.debug("%s finally: await _stream_task exception=%s",
                                 _sa_log_prefix, e)
            if sub_engine in self._child_engines:
                self._child_engines.remove(sub_engine)
            logger.debug(
                "%s finally done text=%d bytes=%d chunk_events=%d",
                _sa_log_prefix, _sa_text_count, _sa_total_bytes, _sa_chunk_count,
            )

        # Normal completion
        yield (StreamEvent.subagent_end(
            "", agent_type=agent_type, status="completed",
        ), "".join(parts))

    _SUBAGENT_SECTION_RE = re.compile(
        r'^(SUMMARY|CHANGES|EVIDENCE|RISKS|BLOCKERS):\s*$',
        re.IGNORECASE | re.MULTILINE,
    )

    def _format_subagent_output(self, agent_type: str, prompt: str, result: str) -> str:
        """Format sub-agent output in DeepSeek-TUI structured contract format.
        
        Output contract:
        SUMMARY: one paragraph; what you did and what happened
        CHANGES: files modified, with one-line descriptions; "None." if read-only
        EVIDENCE: path:line-range citations and key findings; one bullet each
        RISKS: what could go wrong / what the parent should double-check
        BLOCKERS: what stopped you; "None." if you finished cleanly
        """
        # Detect structured sections via line-start regex, not substring match
        has_sections = self._SUBAGENT_SECTION_RE.search(result) is not None

        if has_sections:
            return result

        return (
            f"SUMMARY:\n{agent_type.capitalize()} agent completed task: {prompt[:200]}\n\n"
            f"CHANGES:\nNone detected.\n\n"
            f"EVIDENCE:\n- See detailed output below\n\n"
            f"RISKS:\nNone identified.\n\n"
            f"BLOCKERS:\nNone.\n\n"
            f"--- Raw Output ---\n{result}"
        )

    def spawn_subagent(self, agent_type: str, prompt: str) -> dict:
        if self.current_agent.permission_task == AgentPermission.DENY:
            return {"success": False, "error": "Subagent denied"}
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                future = asyncio.run_coroutine_threadsafe(
                    self._spawn_subagent_async(agent_type, prompt), loop
                )
                result = future.result(timeout=300)
            else:
                result = asyncio.run(self._spawn_subagent_async(agent_type, prompt))
        except Exception as e:
            logger.exception(f"Subagent error: {e}")
            return {"success": False, "error": safe_error_msg(e)}
        return {
            "success": True,
            "agent_type": agent_type,
            "response": result,
            "iterations": 1,
        }

    def tool_task(self, agent_type: str, prompt: str) -> str:
        result = self.spawn_subagent(agent_type, prompt)
        if result["success"]:
            return result["response"]
        return f"Error: {result.get('error') or 'Unknown error'}"

    def attach_session(self, session: AgentSession) -> None:
        self._session = session
        if session.messages:
            self.context.load_from_session(session.messages)
        if session.todos:
            self._todo_manager.reload_from_dict({
                "todos": session.todos,
                "id_counter": len(session.todos),
            })
        # Restore context usage stats
        self._restore_session_stats(session)

    def save_session(self) -> None:
        if self._session:
            try:
                self._session.messages = self.context.to_session_format()
                tm_data = self._todo_manager.to_dict()
                self._session.todos = tm_data.get("todos", [])
                # Persist context usage stats so they survive session reload
                self._session.update_state("stats", {
                    "total_tokens": self.total_tokens,
                    "iterations": self.iterations,
                    "turn_usages": [
                        {k: v for k, v in u.items() if isinstance(v, (int, float))}
                        for u in self._turn_usages
                    ],
                })
                self._session.save()
            except Exception as e:
                logger.exception("Failed to save session: %s", e)

    def load_session(self, session_id: str) -> bool:
        session = AgentSession(session_id)
        if not session.load():
            return False
        self._session = session
        self.context.load_from_session(session.messages)
        if session.todos:
            self._todo_manager.reload_from_dict({
                "todos": session.todos,
                "id_counter": len(session.todos),
            })
            self._inject_loaded_tasks_into_context()
        # Restore context usage stats
        self._restore_session_stats(session)
        return True

    def _inject_loaded_tasks_into_context(self) -> None:
        """Surface loaded todos to the LLM so it can continue them.

        Todos loaded from a previous session are not automatically visible
        in the LLM context — without this nudge the agent would re-create
        them on every fresh turn instead of resuming pending work.
        """
        all_todos = self._todo_manager.list_todos()
        pending = [t for t in all_todos if t.get("status") in ("pending", "in_progress")]
        if not pending:
            return

        lines = ["# Resumed todos from previous session", ""]
        lines.append("## Todos")
        for t in pending:
            status = t.get("status", "pending")
            marker = {"in_progress": "[~]", "pending": "[ ]"}.get(status, "[?]")
            subject = t.get("subject") or t.get("description", "")
            desc = t.get("description") or ""
            if desc and desc != subject:
                lines.append(f"- {marker} (id={t.get('id')}) {subject} — {desc}")
            else:
                lines.append(f"- {marker} (id={t.get('id')}) {subject}")
        lines.append("")

        lines.append(
            "Continue working on any in_progress or pending todos above. "
            "Use TodoList/TodoGet to inspect details and TodoUpdate to "
            "advance status. Do NOT recreate todos that already exist."
        )
        marker = "<!-- loaded_todos_resume -->"
        body = f"{marker}\n" + "\n".join(lines)
        if not self.context.replace_system_section(marker, body):
            self.context.add_system(body)

    def _restore_session_stats(self, session: AgentSession) -> None:
        """Restore context usage stats from session lifecycle_state."""
        stats = session.get_state("stats", {})
        if not stats:
            return
        self.total_tokens = int(stats.get("total_tokens", self.total_tokens))
        self.iterations = int(stats.get("iterations", self.iterations))
        restored_turns = stats.get("turn_usages", [])
        if restored_turns and isinstance(restored_turns, list):
            self._turn_usages = list(restored_turns)

    def save_todos_to_project(self) -> None:
        """Save todos to .cdh/todos.json — uses find_cdh_dir_for_todos
        so sub-projects never overwrite a parent project's todos."""
        from onecode.agent.cdh_loader import CdhProjectLoader
        cdh_dir = CdhProjectLoader.find_cdh_dir_for_todos(self._project_dir)
        if cdh_dir is None:
            cdh_dir = self._project_dir / CdhProjectLoader.CDH_DIRNAME
            try:
                cdh_dir.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                logger.warning("Failed to create .cdh directory: %s", e)
                return
        try:
            tm_data = self._todo_manager.to_dict()
            CdhProjectLoader.save_todos(cdh_dir, tm_data)
        except Exception as e:
            logger.warning("Failed to save todos to .cdh: %s", e)

    def load_todos_from_project(self) -> None:
        """Restore todos from .cdh/todos.json — uses find_cdh_dir_for_todos
        so sub-projects never accidentally load a parent project's todos.
        If todos are found, the ``<!-- NEW_SESSION_HINT -->`` marker is
        removed from the system context (it only applies to blank sessions)."""
        from onecode.agent.cdh_loader import CdhProjectLoader
        cdh_dir = CdhProjectLoader.find_cdh_dir_for_todos(self._project_dir)
        if cdh_dir is None:
            return
        try:
            data = CdhProjectLoader.load_todos(cdh_dir)
            if data and (data.get("tasks") or data.get("todos")):
                self._todo_manager.reload_from_dict(data)
                self.context.remove_system_by_marker("<!-- NEW_SESSION_HINT -->")
        except Exception as e:
            logger.warning("Failed to load todos from .cdh: %s", e)

    def get_session(self) -> Optional[AgentSession]:
        return self._session